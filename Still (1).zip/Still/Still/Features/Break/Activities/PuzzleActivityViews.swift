import SwiftUI

// Small, calm puzzle modules. Puzzle rules live in the domain models
// (`SudokuGame`, `PicrossGame`, `WordSearchGame`); these views only draw them
// and save progress after every move.

// MARK: - Sudoku

struct SudokuActivityView: View {
    let onSolved: () -> Void
    @Environment(AppState.self) private var appState
    @State private var game: SudokuGame?

    var body: some View {
        VStack(spacing: StillTheme.Spacing.l) {
            if let game {
                Text(game.isSolved ? "Solved. Every row, column, and box holds 1 to 6." : "Fill each row, column, and box with 1 to 6.")
                    .font(StillTypography.callout)
                    .foregroundStyle(StillTheme.textSecondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                grid(game)
                if game.isSolved {
                    Button("Start over") { reset() }
                        .buttonStyle(QuietSecondaryButtonStyle())
                } else {
                    numberPad(game)
                    feedback(game)
                }
            }
        }
        .onAppear(perform: load)
    }

    private func grid(_ game: SudokuGame) -> some View {
        let puzzle = game.puzzle
        let conflicts = game.conflictingIndices
        return VStack(spacing: 4) {
            ForEach(0..<puzzle.size, id: \.self) { row in
                HStack(spacing: 4) {
                    ForEach(0..<puzzle.size, id: \.self) { column in
                        let index = row * puzzle.size + column
                        cell(game: game, index: index, isConflict: conflicts.contains(index))
                            .padding(.trailing, (column + 1) % puzzle.boxColumns == 0 && column < puzzle.size - 1 ? 6 : 0)
                    }
                }
                .padding(.bottom, (row + 1) % puzzle.boxRows == 0 && row < puzzle.size - 1 ? 6 : 0)
            }
        }
        .frame(maxWidth: 380)
        .frame(maxWidth: .infinity)
    }

    private func cell(game: SudokuGame, index: Int, isConflict: Bool) -> some View {
        let isGiven = game.puzzle.isGiven(index)
        let isSelected = game.selectedIndex == index
        let value = game.value(at: index)
        let fill: Color = isSelected ? StillTheme.accentSoft
            : isConflict ? StillTheme.attentionSoft
            : isGiven ? StillTheme.surfaceSunken
            : StillTheme.surface
        return Button {
            update { $0.select(index) }
        } label: {
            Text(value.map { String($0) } ?? "")
                .font(StillTypography.title3.weight(isGiven ? .semibold : .regular))
                .foregroundStyle(isGiven ? StillTheme.textPrimary : StillTheme.calm)
                .frame(maxWidth: .infinity)
                .aspectRatio(1, contentMode: .fit)
                .background(RoundedRectangle(cornerRadius: 8, style: .continuous).fill(fill))
                .overlay(
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .strokeBorder(isSelected ? StillTheme.accent : StillTheme.border, lineWidth: StillTheme.Stroke.hairline)
                )
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Row \(game.puzzle.row(of: index) + 1), column \(game.puzzle.column(of: index) + 1)")
        .accessibilityValue(value.map { "\($0)\(isGiven ? ", given" : "")" } ?? "Empty")
        .accessibilityAddTraits(isSelected ? [.isButton, .isSelected] : .isButton)
    }

    private func numberPad(_ game: SudokuGame) -> some View {
        HStack(spacing: StillTheme.Spacing.xs) {
            ForEach(1...game.puzzle.size, id: \.self) { number in
                Button {
                    update { _ = $0.enter(number) }
                } label: {
                    Text("\(number)")
                        .font(StillTypography.title3)
                        .foregroundStyle(StillTheme.textPrimary)
                        .frame(maxWidth: .infinity, minHeight: 48)
                        .background(Capsule(style: .continuous).fill(StillTheme.surface))
                        .overlay(Capsule(style: .continuous).strokeBorder(StillTheme.border, lineWidth: StillTheme.Stroke.hairline))
                        .opacity(game.placedCount(of: number) >= game.puzzle.size ? 0.4 : 1)
                }
                .buttonStyle(.plain)
                .disabled(game.selectedIndex == nil)
                .accessibilityLabel("Enter \(number)")
            }
            Button {
                update { _ = $0.erase() }
            } label: {
                Image(systemName: "delete.left")
                    .font(StillTypography.title3)
                    .foregroundStyle(StillTheme.textSecondary)
                    .frame(maxWidth: .infinity, minHeight: 48)
            }
            .buttonStyle(.plain)
            .disabled(game.selectedIndex == nil)
            .accessibilityLabel("Erase")
        }
    }

    @ViewBuilder
    private func feedback(_ game: SudokuGame) -> some View {
        if !game.conflictingIndices.isEmpty {
            QuietNote(text: "Two of the same number share a row, column, or box.", symbol: "circle.lefthalf.filled")
        } else if game.selectedIndex == nil {
            QuietNote(text: "Tap an empty square, then a number.")
        }
    }

    private func load() {
        guard game == nil else { return }
        let puzzle = appState.container.puzzles.sudoku(for: Date())
        game = appState.container.puzzleProgress.load(SudokuGame.self, puzzleID: puzzle.id) ?? SudokuGame(puzzle: puzzle)
    }

    private func reset() {
        guard let puzzle = game?.puzzle else { return }
        try? appState.container.puzzleProgress.clear(puzzleID: puzzle.id)
        game = SudokuGame(puzzle: puzzle)
    }

    private func update(_ change: (inout SudokuGame) -> Void) {
        guard var current = game else { return }
        let wasSolved = current.isSolved
        change(&current)
        game = current
        try? appState.container.puzzleProgress.save(current, puzzleID: current.puzzle.id, at: Date())
        if current.isSolved && !wasSolved { onSolved() }
    }
}

// MARK: - Picross

struct PicrossActivityView: View {
    let onSolved: () -> Void
    @Environment(AppState.self) private var appState
    @State private var game: PicrossGame?
    @State private var tool: PicrossTool = .fill

    private let clueWidth: CGFloat = 52

    var body: some View {
        VStack(spacing: StillTheme.Spacing.l) {
            if let game {
                Text(game.isSolved ? "Solved: \(game.puzzle.title)." : "Fill squares so each row and column matches its numbers.")
                    .font(StillTypography.callout)
                    .foregroundStyle(StillTheme.textSecondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                if !game.isSolved {
                    SelectionPill(options: [PicrossTool.fill, PicrossTool.cross], selection: $tool) { option in
                        option == .fill ? "Fill" : "Mark empty"
                    }
                }
                board(game)
                if game.isSolved {
                    Button("Start over") { reset() }
                        .buttonStyle(QuietSecondaryButtonStyle())
                }
            }
        }
        .onAppear(perform: load)
    }

    private func board(_ game: PicrossGame) -> some View {
        let size = game.puzzle.size
        let columnClues = game.puzzle.columnClues
        let rowClues = game.puzzle.rowClues
        return VStack(spacing: 4) {
            HStack(alignment: .bottom, spacing: 4) {
                Color.clear.frame(width: clueWidth, height: 1)
                ForEach(0..<size, id: \.self) { column in
                    VStack(spacing: 0) {
                        ForEach(Array(columnClues[column].enumerated()), id: \.offset) { item in
                            Text("\(item.element)")
                        }
                    }
                    .font(StillTypography.footnote.monospacedDigit())
                    .foregroundStyle(game.isColumnSatisfied(column) ? StillTheme.textTertiary : StillTheme.textPrimary)
                    .frame(maxWidth: .infinity)
                    .accessibilityLabel("Column \(column + 1) clue \(columnClues[column].map { String($0) }.joined(separator: " "))")
                }
            }
            ForEach(0..<size, id: \.self) { row in
                HStack(spacing: 4) {
                    Text(rowClues[row].map { String($0) }.joined(separator: " "))
                        .font(StillTypography.footnote.monospacedDigit())
                        .foregroundStyle(game.isRowSatisfied(row) ? StillTheme.textTertiary : StillTheme.textPrimary)
                        .frame(width: clueWidth, alignment: .trailing)
                        .accessibilityLabel("Row \(row + 1) clue \(rowClues[row].map { String($0) }.joined(separator: " "))")
                    ForEach(0..<size, id: \.self) { column in
                        cell(game: game, index: row * size + column, row: row, column: column)
                    }
                }
            }
        }
        .frame(maxWidth: 360)
        .frame(maxWidth: .infinity)
    }

    private func cell(game: PicrossGame, index: Int, row: Int, column: Int) -> some View {
        let state = game.cells[index]
        let filledColor = game.isSolved ? StillTheme.accent : StillTheme.textPrimary
        return Button {
            update { $0.apply(tool, at: index) }
        } label: {
            ZStack {
                RoundedRectangle(cornerRadius: 6, style: .continuous)
                    .fill(state == .filled ? filledColor : StillTheme.surface)
                RoundedRectangle(cornerRadius: 6, style: .continuous)
                    .strokeBorder(StillTheme.border, lineWidth: StillTheme.Stroke.hairline)
                if state == .crossed {
                    Image(systemName: "xmark")
                        .font(StillTypography.caption)
                        .foregroundStyle(StillTheme.textTertiary)
                }
            }
            .aspectRatio(1, contentMode: .fit)
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.plain)
        .disabled(game.isSolved)
        .accessibilityLabel("Row \(row + 1), column \(column + 1)")
        .accessibilityValue(state == .filled ? "Filled" : state == .crossed ? "Marked empty" : "Blank")
    }

    private func load() {
        guard game == nil else { return }
        let puzzle = appState.container.puzzles.picross(for: Date())
        game = appState.container.puzzleProgress.load(PicrossGame.self, puzzleID: puzzle.id) ?? PicrossGame(puzzle: puzzle)
    }

    private func reset() {
        guard let puzzle = game?.puzzle else { return }
        try? appState.container.puzzleProgress.clear(puzzleID: puzzle.id)
        game = PicrossGame(puzzle: puzzle)
    }

    private func update(_ change: (inout PicrossGame) -> Void) {
        guard var current = game else { return }
        let wasSolved = current.isSolved
        change(&current)
        game = current
        try? appState.container.puzzleProgress.save(current, puzzleID: current.puzzle.id, at: Date())
        if current.isSolved && !wasSolved { onSolved() }
    }
}

// MARK: - Word Search

struct WordSearchActivityView: View {
    let onSolved: () -> Void
    @Environment(AppState.self) private var appState
    @State private var game: WordSearchGame?
    @State private var message = "Tap the first letter of a word, then its last letter."

    var body: some View {
        VStack(alignment: .leading, spacing: StillTheme.Spacing.l) {
            if let game {
                Text(game.isSolved ? "All six found." : message)
                    .font(StillTypography.callout)
                    .foregroundStyle(StillTheme.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
                grid(game)
                wordList(game)
                if game.isSolved {
                    Button("Start over") { reset() }
                        .buttonStyle(QuietSecondaryButtonStyle())
                }
            }
        }
        .onAppear(perform: load)
    }

    private func grid(_ game: WordSearchGame) -> some View {
        let puzzle = game.puzzle
        return VStack(spacing: 4) {
            ForEach(0..<puzzle.size, id: \.self) { row in
                HStack(spacing: 4) {
                    ForEach(0..<puzzle.size, id: \.self) { column in
                        letterCell(game: game, point: GridPoint(row: row, column: column))
                    }
                }
            }
        }
        .frame(maxWidth: 380)
        .frame(maxWidth: .infinity)
    }

    private func letterCell(game: WordSearchGame, point: GridPoint) -> some View {
        let letter = game.puzzle.letter(at: point).map { String($0) } ?? ""
        let isFound = game.foundCells.contains(point)
        let isPending = game.pendingStart == point
        let fill: Color = isPending ? StillTheme.highlightSoft : isFound ? StillTheme.accentSoft : StillTheme.surface
        return Button {
            tap(point)
        } label: {
            Text(letter)
                .font(StillTypography.headline)
                .foregroundStyle(StillTheme.textPrimary)
                .frame(maxWidth: .infinity)
                .aspectRatio(1, contentMode: .fit)
                .background(RoundedRectangle(cornerRadius: 8, style: .continuous).fill(fill))
                .overlay(
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .strokeBorder(isPending ? StillTheme.highlight : StillTheme.border, lineWidth: StillTheme.Stroke.hairline)
                )
        }
        .buttonStyle(.plain)
        .disabled(game.isSolved)
        .accessibilityLabel("\(letter), row \(point.row + 1), column \(point.column + 1)")
        .accessibilityValue(isPending ? "Selection started" : isFound ? "Part of a found word" : "")
    }

    private func wordList(_ game: WordSearchGame) -> some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 88), spacing: StillTheme.Spacing.xs)], alignment: .leading, spacing: StillTheme.Spacing.xs) {
            ForEach(game.puzzle.words, id: \.self) { word in
                let found = game.foundWords.contains(word)
                Text(word.capitalized)
                    .font(StillTypography.callout)
                    .strikethrough(found, color: StillTheme.textTertiary)
                    .foregroundStyle(found ? StillTheme.textTertiary : StillTheme.textPrimary)
                    .padding(.horizontal, StillTheme.Spacing.s)
                    .padding(.vertical, StillTheme.Spacing.xxs)
                    .background(Capsule(style: .continuous).fill(found ? StillTheme.accentSoft : StillTheme.surfaceSunken))
                    .accessibilityValue(found ? "Found" : "Not found yet")
            }
        }
    }

    private func tap(_ point: GridPoint) {
        guard var current = game else { return }
        let wasSolved = current.isSolved
        let result = current.tap(point)
        game = current
        switch result {
        case .startedSelection:
            message = "Now tap the word's last letter."
        case .cleared:
            message = "Selection cleared."
        case .found(let word):
            message = "Found \(word.capitalized)."
        case .noMatch:
            message = "Not a word from the list. Try another pair."
        }
        try? appState.container.puzzleProgress.save(current, puzzleID: current.puzzle.id, at: Date())
        if current.isSolved && !wasSolved { onSolved() }
    }

    private func load() {
        guard game == nil else { return }
        let puzzle = appState.container.puzzles.wordSearch(for: Date())
        game = appState.container.puzzleProgress.load(WordSearchGame.self, puzzleID: puzzle.id) ?? WordSearchGame(puzzle: puzzle)
    }

    private func reset() {
        guard let puzzle = game?.puzzle else { return }
        try? appState.container.puzzleProgress.clear(puzzleID: puzzle.id)
        game = WordSearchGame(puzzle: puzzle)
        message = "Tap the first letter of a word, then its last letter."
    }
}

#Preview("Sudoku · unfinished") {
    ActivityContainerView(activityID: .sudoku, context: .shelf)
        .environment(PreviewSupport.appState())
}

#Preview("Picross · finished") {
    let state = PreviewSupport.appState()
    var solved = PicrossGame(puzzle: BundledPuzzleLibrary.sprout)
    for index in solved.puzzle.solution.indices where solved.puzzle.solution[index] {
        solved.apply(.fill, at: index)
    }
    try? state.container.puzzleProgress.save(solved, puzzleID: solved.puzzle.id, at: Date())
    return ActivityContainerView(activityID: .picross, context: .shelf)
        .environment(state)
}
