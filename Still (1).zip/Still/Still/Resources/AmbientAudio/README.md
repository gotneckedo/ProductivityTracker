# Ambient audio assets

`AVAmbientAudioPlayer` looks for one looping file per source in the app
bundle, trying `.m4a`, then `.caf`, `.wav`, `.mp3`:

| Source    | Expected base name  | Bundled in V1                         |
|-----------|---------------------|---------------------------------------|
| Rain      | `ambient_rain`      | `ambient_rain.m4a` (generated)        |
| Café      | `ambient_cafe`      | `ambient_cafe.m4a` (generated)        |
| Fireplace | `ambient_fireplace` | `ambient_fireplace.m4a` (generated)   |
| Waves     | `ambient_waves`     | `ambient_waves.m4a` (generated)       |

## What ships today

The four V1 files are **original, procedurally generated placeholders**:
filtered noise, synthetic droplets, crackles, and soft tones made with
NumPy/SciPy and encoded with ffmpeg (AAC, mono, 80 kbps, 40-second loops with a
3-second crossfade at the seam). No recordings or third-party audio were used,
so there is nothing to license or credit. They are serviceable, not beautiful.
The café loop in particular is an abstract "room murmur" rather than a real
café. Replacing them with better loops is a good early polish task.

## Replacing a loop

1. Keep the exact base name (e.g. `ambient_rain.m4a`) and drop the file into
   this folder. The Xcode project uses a synchronized folder, so it is added to
   the app target automatically.
2. Aim for 30–90 seconds, mono or stereo, seamless loop points, peaks near
   −6 dBFS, and no sudden events in the first or last second.
3. `.caf` with linear PCM loops with no gap at all. AAC `.m4a` is smaller and
   loops cleanly on device in practice, but check the seam by ear.

## Licensing rules

- Use only audio you recorded, generated, commissioned, or licensed for app
  distribution. CC0 is ideal. CC-BY is fine if the credit goes in the app and in
  `ASSET_AND_CONTENT_POLICY.md`. Do not use CC-NC or "personal use" loops.
- Never download loops from the reference apps (Endel, lofi streams, etc.).
- Record provenance for each file in `ASSET_AND_CONTENT_POLICY.md`: source,
  author, license, date, and a link to the license text.

## If files are missing

Nothing breaks. A missing source stays silent; if every file is missing, the UI
shows "Ambient audio is ready when sound files are added." and the mix controls
still save. No broken player or fake meters appear.

This README is excluded from the app target in the Xcode project.
