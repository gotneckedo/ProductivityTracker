#if canImport(ActivityKit) && os(iOS)
import ActivityKit
import Foundation

/// Real Live Activity updates. Only used when `FeatureFlags.liveActivities`
/// is on AND the StillLiveActivity widget extension is part of the build;
/// without the extension, iOS has nothing to render. See README.
final class ActivityKitLiveActivityUpdater: LiveActivityUpdating {
    private var activity: Activity<StillActivityAttributes>?

    var isAvailable: Bool {
        ActivityAuthorizationInfo().areActivitiesEnabled
    }

    func startOrUpdate(sessionID: UUID, state: LiveActivityState) {
        let content = ActivityContent(state: state, staleDate: state.phaseEndDate?.addingTimeInterval(60))
        if let current = activity, current.attributes.sessionID == sessionID {
            Task { await current.update(content) }
            return
        }
        endAll()
        guard isAvailable else { return }
        do {
            activity = try Activity.request(
                attributes: StillActivityAttributes(sessionID: sessionID),
                content: content,
                pushType: nil
            )
        } catch {
            // Live Activities are optional; the in-app timer is the source of truth.
            activity = nil
        }
    }

    func end(sessionID: UUID) {
        guard let current = activity, current.attributes.sessionID == sessionID else { return }
        activity = nil
        Task { await current.end(nil, dismissalPolicy: .immediate) }
    }

    private func endAll() {
        let existing = Activity<StillActivityAttributes>.activities
        activity = nil
        for item in existing {
            Task { await item.end(nil, dismissalPolicy: .immediate) }
        }
    }
}
#endif
