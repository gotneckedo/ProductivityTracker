import Foundation

/// Maps timer state to Live Activity content. Pure and testable.
enum LiveActivityMapper {
    static func state(for snapshot: TimerSnapshot, sceneName: String, now: Date) -> LiveActivityState? {
        guard snapshot.state.isLive else { return nil }

        let headline: String
        if snapshot.isAwaitingNextPhase {
            headline = snapshot.nextPhaseKind == .focus ? "Break's over" : "Break ready"
        } else if snapshot.isPaused {
            headline = "Paused"
        } else {
            headline = snapshot.phaseKind.displayName
        }

        let isCountUp = snapshot.phaseDuration == nil
        let countUpStart: Date? = (isCountUp && snapshot.isRunning)
            ? now.addingTimeInterval(-snapshot.elapsedInPhase)
            : nil

        return LiveActivityState(
            isBreak: snapshot.phaseKind.isBreak,
            isPaused: snapshot.isPaused,
            isAwaitingNextPhase: snapshot.isAwaitingNextPhase,
            phaseEndDate: snapshot.phaseEndDate,
            countUpStartDate: countUpStart,
            frozenSeconds: snapshot.isRunning ? nil : snapshot.displayedSeconds,
            focusBlockNumber: snapshot.focusBlockNumber,
            focusBlockCount: snapshot.focusBlockCount,
            sceneName: sceneName,
            headline: headline
        )
    }
}

/// Boundary for Lock Screen and Dynamic Island updates. The app is fully
/// functional with `NoopLiveActivityUpdater`.
protocol LiveActivityUpdating: AnyObject {
    var isAvailable: Bool { get }
    func startOrUpdate(sessionID: UUID, state: LiveActivityState)
    func end(sessionID: UUID)
}

final class NoopLiveActivityUpdater: LiveActivityUpdating {
    let isAvailable = false
    private(set) var lastState: LiveActivityState?
    private(set) var endedSessionIDs: [UUID] = []

    func startOrUpdate(sessionID: UUID, state: LiveActivityState) {
        lastState = state
    }

    func end(sessionID: UUID) {
        lastState = nil
        endedSessionIDs.append(sessionID)
    }
}
