// V2 scaffold for in-app tag scanning and tag writing.
//
// Compiled only when the `STILL_CORENFC` Swift flag is set (Build Settings →
// Other Swift Flags → -DSTILL_CORENFC), because it also needs:
//   • the "Near Field Communication Tag Reading" capability
//     (com.apple.developer.nfc.readersession.formats = [NDEF])
//   • NFCReaderUsageDescription in Info.plist
//   • a physical iPhone (the simulator cannot scan)
//
// V1 does not need this file: tags written with a still:// URL open the app
// through the URL scheme, which `DeepLinkParser` already handles.
#if canImport(CoreNFC) && os(iOS) && STILL_CORENFC
import CoreNFC
import Foundation

final class CoreNFCTagReader: NSObject, NFCNDEFReaderSessionDelegate {
    private var session: NFCNDEFReaderSession?
    private var completion: ((URL?) -> Void)?

    static var isAvailable: Bool { NFCNDEFReaderSession.readingAvailable }

    /// Scans one tag and returns the first URL record, if any.
    func scan(completion: @escaping (URL?) -> Void) {
        guard Self.isAvailable else {
            completion(nil)
            return
        }
        self.completion = completion
        session = NFCNDEFReaderSession(delegate: self, queue: nil, invalidateAfterFirstRead: true)
        session?.alertMessage = "Hold your iPhone near your Focus Card."
        session?.begin()
    }

    func readerSession(_ session: NFCNDEFReaderSession, didDetectNDEFs messages: [NFCNDEFMessage]) {
        let url = messages
            .flatMap(\.records)
            .compactMap { $0.wellKnownTypeURIPayload() }
            .first
        DispatchQueue.main.async { [weak self] in
            self?.completion?(url)
            self?.completion = nil
        }
    }

    func readerSession(_ session: NFCNDEFReaderSession, didInvalidateWithError error: Error) {
        DispatchQueue.main.async { [weak self] in
            self?.completion?(nil)
            self?.completion = nil
        }
    }

    // TODO(V2-writing): implement tag writing with `readerSession(_:didDetect:)`,
    // `connect(to:)`, `queryNDEFStatus`, and `writeNDEF` using
    // `NFCNDEFPayload.wellKnownTypeURIPayload(url: preset.startURL)`.
}
#endif
