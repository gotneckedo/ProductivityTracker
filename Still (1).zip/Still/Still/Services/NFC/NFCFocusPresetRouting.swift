import Foundation

enum NFCRoutingResult: Equatable {
    case startPreset(FocusPresetID)
    /// A well-formed link naming a preset this device doesn't have.
    case unknownPreset(FocusPresetID)
    case notAFocusLink
}

/// Turns a URL (from an NFC tag, Universal Link, Shortcut, or the in-app
/// simulator) into a preset to start.
///
/// Real tag behavior: an iPhone cannot react to an arbitrary blank tag while
/// the app is closed. A tag must be written with an NDEF URI record containing
/// the preset URL. iOS reads URL records in the background and offers to open
/// the app; with a configured associated domain, a Universal Link record opens
/// it directly. This must be verified on hardware (see README).
protocol NFCFocusPresetRouting {
    func route(_ url: URL) -> NFCRoutingResult
}

struct DeepLinkPresetRouter: NFCFocusPresetRouting {
    var parser = DeepLinkParser()
    var knownPresetIDs: Set<FocusPresetID>

    func route(_ url: URL) -> NFCRoutingResult {
        guard case .startFocus(let presetID)? = parser.parse(url) else { return .notAFocusLink }
        return knownPresetIDs.contains(presetID) ? .startPreset(presetID) : .unknownPreset(presetID)
    }
}

/// The honest setup guide shown on the Focus Card screen.
enum FocusCardGuide {
    static let summary = "A Focus Card is any writable NFC tag programmed with a Still link. Tap it with your iPhone to start a preset."

    static let steps: [String] = [
        "Get a writable NFC tag (NTAG213 or similar). A blank tag does nothing on its own.",
        "Use an NFC writing app to add a URL record with the link below.",
        "Hold the top of your iPhone near the tag. iOS shows a banner; tap it to open Still.",
        "Still starts the preset. If a session is already running, it leaves that session alone."
    ]

    static let hardwareNote = "Tag reading depends on your iPhone model and iOS settings, so test your card on your own device. The simulator below runs the same route without a tag."
}
