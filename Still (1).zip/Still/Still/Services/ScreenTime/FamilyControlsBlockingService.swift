#if canImport(FamilyControls) && os(iOS)
import FamilyControls
import Foundation

/// V2 scaffold for real Screen Time shielding. NOT used in V1: the container
/// injects `MockFocusBlockingService` until `FeatureFlags.appBlocking` is on.
///
/// Compiles without the entitlement; it only fails at runtime if called
/// without it. Before enabling:
/// 1. Request the Family Controls (Distribution) entitlement from Apple and add
///    `com.apple.developer.family-controls` to Still.entitlements.
/// 2. TODO(V2-authorization): call `requestAuthorization()` from a calm,
///    explained setup screen (never at launch).
/// 3. TODO(V2-selection): present `FamilyActivityPicker`, then persist the
///    `FamilyActivitySelection` (it is Codable) per preset.
/// 4. TODO(V2-shielding): import ManagedSettings and, in `sessionDidStart`,
///    apply `ManagedSettingsStore(named:)` shields for the preset's selection;
///    clear them in `sessionDidEnd`. Add a DeviceActivity monitor extension so
///    shields lift even if the app is killed.
/// 5. TODO(V2-override): add an emergency override that ends shielding and
///    records a local audit event.
final class FamilyControlsBlockingService: FocusBlockingService {
    private(set) var capability: BlockingCapability = .notAuthorized
    /// Stays false until shielding is really applied (TODO(V2-shielding)).
    private(set) var isShielding = false

    init() {
        refreshAuthorization()
    }

    func refreshAuthorization() {
        switch AuthorizationCenter.shared.authorizationStatus {
        case .approved:
            capability = .authorized
        default:
            capability = .notAuthorized
        }
    }

    func requestAuthorization() async throws {
        try await AuthorizationCenter.shared.requestAuthorization(for: .individual)
        refreshAuthorization()
    }

    func sessionDidStart(sessionID: UUID, intent: BlockerIntent) {
        guard capability == .authorized, intent != .none else { return }
        // TODO(V2-shielding): apply ManagedSettingsStore shields here, then set isShielding = true.
    }

    func sessionDidEnd(sessionID: UUID) {
        // TODO(V2-shielding): clear ManagedSettingsStore shields here.
        isShielding = false
    }
}
#endif
