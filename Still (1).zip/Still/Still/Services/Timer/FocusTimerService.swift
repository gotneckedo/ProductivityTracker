import Foundation

/// The timer boundary used by the app. `FocusTimerEngine` is the V1
/// implementation: pure, date-based, and deterministic under an injected clock.
/// A future implementation could add, for example, routine-aware scheduling.
protocol FocusTimerService {
    func makeSession(
        id: UUID,
        configuration: TimerConfiguration,
        taskID: UUID?,
        sceneID: SceneID,
        renderMode: RenderMode,
        presetID: FocusPresetID,
        source: SessionSource,
        at now: Date
    ) -> FocusSession
    func advance(_ session: FocusSession, to now: Date) -> (FocusSession, [TimerTransition])
    func snapshot(of session: FocusSession, at now: Date) -> TimerSnapshot
    func pause(_ session: FocusSession, at now: Date) -> (FocusSession, [TimerTransition])
    func resume(_ session: FocusSession, at now: Date) -> FocusSession
    func startNextPhase(_ session: FocusSession, at now: Date) -> (FocusSession, [TimerTransition])
    func skipBreak(_ session: FocusSession, at now: Date) -> (FocusSession, [TimerTransition])
    func finishCountUp(_ session: FocusSession, at now: Date) -> FocusSession
    func abandon(_ session: FocusSession, at now: Date) -> FocusSession
    func upcomingBoundaries(_ session: FocusSession, from now: Date) -> [PhaseBoundary]
}

extension FocusTimerEngine: FocusTimerService {}

/// Formats durations for the timer face and stats. Display-only; never stored.
enum DurationFormatter {
    /// "24:59" or "1:04:10".
    static func clock(_ seconds: TimeInterval) -> String {
        let total = max(0, Int(seconds.rounded(.up)))
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let secs = total % 60
        if hours > 0 {
            return String(format: "%d:%02d:%02d", hours, minutes, secs)
        }
        return String(format: "%02d:%02d", minutes, secs)
    }

    /// Count-up clocks round down so the first second reads 00:00.
    static func elapsedClock(_ seconds: TimeInterval) -> String {
        clock(max(0, seconds.rounded(.down)))
    }

    /// "25 min", "1 h 5 min", "45 sec".
    static func short(_ seconds: TimeInterval) -> String {
        let total = max(0, Int(seconds.rounded()))
        if total < 60 { return "\(total) sec" }
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        if hours > 0 {
            return minutes > 0 ? "\(hours) h \(minutes) min" : "\(hours) h"
        }
        return "\(minutes) min"
    }

    /// VoiceOver-friendly: "12 minutes 30 seconds".
    static func spoken(_ seconds: TimeInterval) -> String {
        let total = max(0, Int(seconds.rounded(.up)))
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let secs = total % 60
        var parts: [String] = []
        if hours > 0 { parts.append("\(hours) \(hours == 1 ? "hour" : "hours")") }
        if minutes > 0 { parts.append("\(minutes) \(minutes == 1 ? "minute" : "minutes")") }
        if secs > 0 || parts.isEmpty { parts.append("\(secs) \(secs == 1 ? "second" : "seconds")") }
        return parts.joined(separator: " ")
    }
}
