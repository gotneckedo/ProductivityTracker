import XCTest
#if canImport(StillCore)
@testable import StillCore
#else
@testable import Still
#endif

final class PuzzleTests: XCTestCase {
    func testBundledSudokuIsValidAndUnique() {
        let puzzle = BundledPuzzleLibrary.sudoku6
        XCTAssertEqual(puzzle.givens.count, 36)
        XCTAssertEqual(puzzle.solution.count, 36)
        for index in 0..<36 where puzzle.givens[index] != 0 {
            XCTAssertEqual(puzzle.givens[index], puzzle.solution[index], "given disagrees with solution at \(index)")
        }
        for index in 0..<36 {
            for peer in puzzle.peers(of: index) {
                XCTAssertNotEqual(puzzle.solution[index], puzzle.solution[peer])
            }
        }
        XCTAssertEqual(SudokuSolver.countSolutions(puzzle), 1)
    }

    func testSudokuGameplay() {
        var game = SudokuGame(puzzle: BundledPuzzleLibrary.sudoku6)
        XCTAssertFalse(game.hasProgress)

        let givenIndex = game.puzzle.givens.firstIndex { $0 != 0 }!
        game.select(givenIndex)
        XCTAssertFalse(game.enter(1), "givens are locked")

        let empty = game.puzzle.givens.firstIndex(of: 0)!
        game.select(empty)
        let peerValue = game.puzzle.peers(of: empty).compactMap { game.value(at: $0) }.first!
        XCTAssertTrue(game.enter(peerValue))
        XCTAssertFalse(game.conflictingIndices.isEmpty, "gentle conflict feedback")
        XCTAssertTrue(game.erase())

        for index in 0..<36 where game.puzzle.givens[index] == 0 {
            game.select(index)
            game.enter(game.puzzle.solution[index])
        }
        XCTAssertTrue(game.isSolved)
        XCTAssertTrue(game.conflictingIndices.isEmpty)
        game.select(empty)
        XCTAssertFalse(game.erase(), "finished puzzles are read-only")
    }

    func testBundledPicrossIsUnique() {
        let puzzle = BundledPuzzleLibrary.sprout
        XCTAssertEqual(puzzle.size, 5)
        XCTAssertEqual(puzzle.rowClues, [[1, 1], [1], [1], [5], [3]])
        XCTAssertEqual(puzzle.columnClues, [[1], [1, 2], [4], [1, 2], [1]])
        XCTAssertEqual(PicrossSolver.countSolutions(rowClues: puzzle.rowClues, columnClues: puzzle.columnClues, size: 5), 1)
    }

    func testPicrossGameplayIgnoresCrosses() {
        var game = PicrossGame(puzzle: BundledPuzzleLibrary.sprout)
        for index in game.puzzle.solution.indices {
            game.apply(game.puzzle.solution[index] ? .fill : .cross, at: index)
        }
        XCTAssertTrue(game.isSolved)
        XCTAssertTrue((0..<5).allSatisfy(game.isRowSatisfied))
    }

    func testPicrossToggle() {
        var game = PicrossGame(puzzle: BundledPuzzleLibrary.sprout)
        game.apply(.fill, at: 0)
        XCTAssertEqual(game.cells[0], .filled)
        game.apply(.fill, at: 0)
        XCTAssertEqual(game.cells[0], .empty)
        game.apply(.cross, at: 0)
        XCTAssertEqual(game.cells[0], .crossed)
    }

    func testWordSearchWordsAppearExactlyOnce() {
        let puzzle = BundledPuzzleLibrary.quietWords
        XCTAssertEqual(puzzle.rows.count, puzzle.size)
        XCTAssertTrue(puzzle.rows.allSatisfy { $0.count == puzzle.size })
        for word in puzzle.words {
            XCTAssertEqual(puzzle.occurrences(of: word).count, 1, word)
        }
    }

    func testWordSearchTapToSelectBothDirections() {
        let puzzle = BundledPuzzleLibrary.quietWords
        var game = WordSearchGame(puzzle: puzzle)
        for word in puzzle.words {
            let points = puzzle.occurrences(of: word)[0]
            let reversed = word == "TEA"
            _ = game.tap(reversed ? points.last! : points.first!)
            XCTAssertEqual(game.tap(reversed ? points.first! : points.last!), .found(word))
        }
        XCTAssertTrue(game.isSolved)
    }

    func testWordSearchRejectsNonLines() {
        var game = WordSearchGame(puzzle: BundledPuzzleLibrary.quietWords)
        _ = game.tap(GridPoint(row: 0, column: 0))
        XCTAssertEqual(game.tap(GridPoint(row: 1, column: 2)), .noMatch)
        XCTAssertEqual(game.tap(GridPoint(row: 3, column: 3)), .startedSelection(GridPoint(row: 3, column: 3)))
        XCTAssertEqual(game.tap(GridPoint(row: 3, column: 3)), .cleared)
    }

    func testPuzzleProgressSurvivesLeaving() throws {
        let container = makeContainer()
        var game = SudokuGame(puzzle: BundledPuzzleLibrary.sudoku6)
        let empty = game.puzzle.givens.firstIndex(of: 0)!
        game.select(empty)
        game.enter(game.puzzle.solution[empty])
        try container.puzzleProgress.save(game, puzzleID: game.puzzle.id, at: referenceDate)
        let loaded = container.puzzleProgress.load(SudokuGame.self, puzzleID: game.puzzle.id)
        XCTAssertEqual(loaded?.value(at: empty), game.puzzle.solution[empty])
    }
}

final class GuidedActivityTests: XCTestCase {
    func testBoxBreathingCycle() {
        let pattern = BreathingPattern.box
        XCTAssertEqual(pattern.totalDuration, 120)
        XCTAssertEqual(pattern.state(at: 0).label, "Inhale")
        XCTAssertEqual(pattern.state(at: 4).label, "Hold")
        XCTAssertEqual(pattern.state(at: 9).label, "Exhale")
        XCTAssertEqual(pattern.state(at: 13).label, "Hold")
        XCTAssertEqual(pattern.state(at: 17).label, "Inhale")
        XCTAssertEqual(pattern.state(at: 2).stepProgress, 0.5, accuracy: 0.0001)
        XCTAssertTrue(pattern.state(at: 120).isFinished)
        XCTAssertEqual(pattern.state(at: 60).remaining, 60)
    }

    func testStretchRoutineIsFourStepsWithSafetyNote() {
        let routine = StretchRoutine.desk
        XCTAssertEqual(routine.steps.count, 4)
        XCTAssertTrue(routine.safetyNote.contains("Stop if anything hurts"))
        XCTAssertTrue(routine.steps.allSatisfy { $0.duration > 0 })
    }

    func testActivityCountdown() {
        let countdown = ActivityCountdown(startedAt: referenceDate, duration: 60)
        XCTAssertEqual(countdown.remaining(at: referenceDate.addingTimeInterval(20)), 40)
        XCTAssertTrue(countdown.isFinished(at: referenceDate.addingTimeInterval(61)))
    }

    func testShortReadsHaveProvenanceAndEnd() {
        let library = BundledReadingLibrary()
        XCTAssertGreaterThanOrEqual(library.allItems().count, 3)
        for item in library.allItems() {
            XCTAssertFalse(item.title.isEmpty)
            XCTAssertFalse(item.author.isEmpty)
            XCTAssertFalse(item.licenseNote.isEmpty)
            XCTAssertEqual(item.license, .originalForStill)
            XCTAssertGreaterThanOrEqual(item.readMinutes, 1)
            XCTAssertLessThanOrEqual(item.readMinutes, 5, "short reads stay short")
        }
    }

    func testCreativePromptRotatesDaily() {
        let today = CreativePromptLibrary.prompt(for: referenceDate, calendar: testCalendar)
        let tomorrow = CreativePromptLibrary.prompt(for: referenceDate.addingTimeInterval(86_400), calendar: testCalendar)
        XCTAssertNotEqual(today.id, tomorrow.id)
    }

    func testCatalogHasEveryV1Activity() {
        let ids = Set(ActivityCatalog.available.map(\.id))
        XCTAssertEqual(ids, [.sudoku, .picross, .wordSearch, .shortRead, .creativePrompt, .brainDump, .guidedStretch, .boxBreathing, .doNothing])
        XCTAssertEqual(ActivityCatalog.grouped().map(\.category), [.puzzle, .quiet, .reset])
    }
}

final class BreakFlowTests: XCTestCase {
    func testUsageLifecycleIsPersistedAndIdempotent() {
        let clock = ManualClock(referenceDate)
        let container = makeContainer(clock: clock)
        let usage = container.breaks.begin(.doNothing, context: .shelf)
        XCTAssertEqual(container.breaks.usedToday(), [.doNothing])
        clock.advance(by: 60)
        container.breaks.finish(usageID: usage.id, outcome: .completed)
        container.breaks.finish(usageID: usage.id, outcome: .abandoned)
        let stored = container.usages.usage(id: usage.id)!
        XCTAssertEqual(stored.outcome, .completed)
        XCTAssertEqual(stored.endedAt, referenceDate.addingTimeInterval(60))

        clock.advance(by: 86_400)
        XCTAssertTrue(container.breaks.usedToday().isEmpty, "yesterday's use doesn't block today's suggestions")
    }

    func testStaleUsagesCloseAsAbandoned() {
        let container = makeContainer()
        let usage = container.breaks.begin(.sudoku, context: .shelf)
        container.breaks.closeStaleUsages()
        XCTAssertEqual(container.usages.usage(id: usage.id)?.outcome, .abandoned)
    }

    func testNotesSaveTrimmedAndSkipEmpty() {
        let container = makeContainer()
        XCTAssertNil(container.breaks.saveNote(text: "   ", kind: .brainDump, activityID: .brainDump, promptID: nil))
        let note = container.breaks.saveNote(text: "  groceries, call back  ", kind: .brainDump, activityID: .brainDump, promptID: nil)
        XCTAssertEqual(note?.text, "groceries, call back")
        XCTAssertEqual(container.breaks.recentNotes(kind: .brainDump).count, 1)
        XCTAssertTrue(container.breaks.recentNotes(kind: .creativeResponse).isEmpty)

        // Autosave updates the same note in place, then clearing removes it.
        let edited = container.breaks.saveNote(text: "groceries, call back, laundry", kind: .brainDump,
                                               activityID: .brainDump, promptID: nil, existingID: note?.id)
        XCTAssertEqual(edited?.id, note?.id)
        XCTAssertEqual(edited?.createdAt, note?.createdAt)
        XCTAssertEqual(container.breaks.recentNotes(kind: .brainDump).count, 1)
        container.breaks.deleteNote(id: note!.id)
        XCTAssertTrue(container.breaks.recentNotes(kind: .brainDump).isEmpty)
    }
}

final class PersistenceTests: XCTestCase {
    func testPreferencesDecodeWithMissingKeys() throws {
        let data = Data(#"{"hasCompletedOnboarding": true, "onboardingGoal": "scrollLess"}"#.utf8)
        let prefs = try RecordCoding.decoder().decode(UserPreferences.self, from: data)
        XCTAssertTrue(prefs.hasCompletedOnboarding)
        XCTAssertEqual(prefs.onboardingGoal, .scrollLess)
        XCTAssertEqual(prefs.defaultPresetID, .defaultPreset)
        XCTAssertEqual(prefs.animationIntensity, .full)
    }

    func testPreferencesTolerateUnknownEnumValues() throws {
        let data = Data(#"{"onboardingGoal": "somethingNew", "animationIntensity": "wild"}"#.utf8)
        let prefs = try RecordCoding.decoder().decode(UserPreferences.self, from: data)
        XCTAssertNil(prefs.onboardingGoal)
        XCTAssertEqual(prefs.animationIntensity, .full)
    }

    func testOnboardingPersonalizesPresetsWithoutLockingIn() {
        let container = makeContainer()
        container.preferences.completeOnboarding(goal: .calmerPhone)
        let preset = container.preferences.preset(.defaultPreset)
        XCTAssertEqual(preset.renderMode, .calm)
        XCTAssertTrue(preset.ambientMix.isSilent)
        XCTAssertEqual(preset.timer.focusDuration, minutes(25), "lands on a 25-minute default")
        XCTAssertTrue(container.preferencesStore.load().hasCompletedOnboarding)

        // The user can still change anything.
        var edited = preset
        edited.renderMode = .scene
        container.preferences.save(edited)
        XCTAssertEqual(container.preferences.preset(.defaultPreset).renderMode, .scene)

        container.preferences.resetOnboarding()
        XCTAssertFalse(container.preferencesStore.load().hasCompletedOnboarding)
    }

    func testPresetEditsAreValidated() {
        let container = makeContainer()
        var preset = container.preferences.preset(.study)
        preset.timer.cycleCount = 99
        container.preferences.save(preset)
        XCTAssertEqual(container.preferences.preset(.study).timer.cycleCount, TimerConfiguration.cycleRange.upperBound)
    }

    func testResetAllDataClearsEverything() {
        let clock = ManualClock(referenceDate)
        let container = makeContainer(clock: clock)
        PreviewFixtures.populate(container)
        XCTAssertFalse(container.sessions.allSessions().isEmpty)
        container.preferences.resetAllData()
        XCTAssertTrue(container.sessions.allSessions().isEmpty)
        XCTAssertTrue(container.tasks.allTasks().isEmpty)
        XCTAssertTrue(container.usages.allUsages().isEmpty)
        XCTAssertFalse(container.preferencesStore.load().hasCompletedOnboarding)
        XCTAssertTrue(container.events.recentEvents.isEmpty)
    }

    func testCorruptRecordsAreSkipped() throws {
        let store = InMemoryRecordStore()
        try store.upsert(StoredRecord(id: "bad", kind: .session, createdAt: referenceDate, updatedAt: referenceDate,
                                      schemaVersion: 1, payload: Data("not json".utf8)))
        let repository = StoredSessionRepository(store: store)
        try repository.save(completedSession(endingAt: referenceDate))
        XCTAssertEqual(repository.allSessions().count, 1)
    }

    func testWriteFailureIsReportedNotFatal() {
        let store = InMemoryRecordStore()
        let container = DependencyContainer(
            clock: ManualClock(referenceDate), calendar: testCalendar, recordStore: store,
            keyValueStore: InMemoryKeyValueStore(), notifications: RecordingNotificationScheduler(),
            audio: SilentAmbientAudioPlayer(), blocking: MockFocusBlockingService(), liveActivity: NoopLiveActivityUpdater()
        )
        var reported = 0
        container.focus.onPersistenceError = { _ in reported += 1 }
        store.failsWrites = true
        container.focus.start(presetID: .defaultPreset, taskID: nil, source: .manual)
        XCTAssertEqual(reported, 1)
        XCTAssertNotNil(container.focus.activeSession, "the session keeps running in memory")
    }

    func testJournalRepositoryIsReadyForV11() throws {
        let container = makeContainer()
        try container.journal.save(JournalEntry(id: UUID(), day: testCalendar.startOfDay(for: referenceDate),
                                                createdAt: referenceDate, text: "Quiet day.", mood: .calm))
        XCTAssertEqual(container.journal.allEntries().first?.mood, .calm)
    }

    func testFixturesProduceMeaningfulStats() {
        let clock = ManualClock(referenceDate)
        let container = makeContainer(clock: clock)
        PreviewFixtures.populate(container)
        let stats = StatsCalculator(calendar: testCalendar).stats(sessions: container.sessions.allSessions(),
                                                                  usages: container.usages.allUsages(), now: clock.now)
        XCTAssertEqual(stats.completedSessions, 9)
        XCTAssertGreaterThan(stats.currentStreak, 0)
        XCTAssertFalse(stats.activityUsage.isEmpty)
    }
}
