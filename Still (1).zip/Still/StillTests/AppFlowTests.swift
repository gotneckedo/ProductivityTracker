import XCTest
#if canImport(StillCore)
@testable import StillCore
#else
@testable import Still
#endif

/// End-to-end checks of the primary loop at the app-state level:
/// onboarding → Focus → complete → "What instead?" → activity → Focus.
final class AppFlowTests: XCTestCase {
    var clock: ManualClock!
    var state: AppState!

    override func setUp() {
        super.setUp()
        clock = ManualClock(referenceDate)
        state = AppState(container: makeContainer(clock: clock))
        state.bootstrap()
    }

    func testOnboardingLandsOnFocusWithTwentyFiveMinuteDefault() {
        XCTAssertFalse(state.preferences.hasCompletedOnboarding)
        state.completeOnboarding(goal: .scrollLess)
        XCTAssertTrue(state.preferences.hasCompletedOnboarding)
        XCTAssertEqual(state.router.selectedTab, .focus)
        XCTAssertEqual(state.currentPreset.timer.focusDuration, minutes(25))
        XCTAssertEqual(state.personalization.categoryOrder.first, .puzzle)
    }

    func testPrimaryLoop() {
        state.completeOnboarding(goal: .focusBetter)
        let task = state.createTask(title: "Biology homework")!
        XCTAssertEqual(state.selectedTask?.id, task.id, "new tasks are selected for the next session")

        state.startFocus()
        let sessionID = try! XCTUnwrap(state.activeSession?.id)
        XCTAssertEqual(state.activeSession?.taskID, task.id)

        // Background for the whole session, then return.
        clock.advance(by: minutes(26))
        state.handleBecameActive()
        XCTAssertNil(state.activeSession)
        XCTAssertEqual(state.router.completion?.sessionID, sessionID)

        let suggestions = state.suggestions(for: sessionID)
        XCTAssertEqual(suggestions.activities.count, 3)
        XCTAssertEqual(state.suggestions(for: sessionID), suggestions, "stable while the screen is open")

        let pick = suggestions.activities[1]
        state.openSuggestion(pick, rank: 1, sessionID: sessionID)
        XCTAssertNil(state.router.completion)
        XCTAssertNil(state.preferences.pendingCompletionSessionID)
        XCTAssertEqual(state.router.selectedTab, .breakShelf)
        XCTAssertEqual(state.router.breakPath, [.breakActivity(pick.id, ActivityContext(entryPoint: .suggestion, sessionID: sessionID, suggestionRank: 1))])

        let usage = state.beginActivity(pick.id, context: ActivityContext(entryPoint: .suggestion, sessionID: sessionID, suggestionRank: 1))
        clock.advance(by: 90)
        state.finishActivity(usage.id, outcome: .completed)
        XCTAssertTrue(state.usedToday(pick.id))

        state.returnToFocusFromActivity()
        XCTAssertEqual(state.router.selectedTab, .focus)
        XCTAssertTrue(state.router.breakPath.isEmpty)

        XCTAssertEqual(state.stats.completedSessions, 1)
        XCTAssertEqual(state.stats.activitiesCompleted, 1)
        let names = state.container.events.recentEvents.map(\.name)
        XCTAssertTrue(names.contains(.breakSuggestionsPresented))
        XCTAssertEqual(names.last, .returnedToFocus)
        XCTAssertEqual(names.filter { $0 == .breakSuggestionsPresented }.count, 1)
    }

    func testSeeAllOpensShelfAndReturnToFocusClosesCompletion() {
        state.completeOnboarding(goal: .focusBetter)
        state.startFocus()
        clock.advance(by: minutes(25))
        state.tick()
        let id = try! XCTUnwrap(state.router.completion?.sessionID)
        state.openShelfFromCompletion()
        XCTAssertEqual(state.router.selectedTab, .breakShelf)
        XCTAssertTrue(state.router.breakPath.isEmpty)
        XCTAssertNil(state.router.completion)

        state.router.go(to: .sessionComplete(id))
        state.returnToFocusFromCompletion()
        XCTAssertEqual(state.router.selectedTab, .focus)
        XCTAssertNil(state.router.completion)
    }

    func testPendingCompletionReopensAfterRelaunch() {
        state.completeOnboarding(goal: .focusBetter)
        state.startFocus()
        let id = state.activeSession!.id
        clock.advance(by: minutes(40))

        let relaunched = AppState(container: DependencyContainer(
            clock: clock, calendar: testCalendar,
            recordStore: state.container.recordStore, keyValueStore: state.container.keyValueStore,
            notifications: RecordingNotificationScheduler(), audio: SilentAmbientAudioPlayer(),
            blocking: MockFocusBlockingService(), liveActivity: NoopLiveActivityUpdater()))
        relaunched.bootstrap()
        XCTAssertEqual(relaunched.router.completion?.sessionID, id)
    }

    func testDeepLinksAndFocusCardSimulator() {
        state.handle(url: URL(string: "still://start-focus?preset=study")!)
        XCTAssertNil(state.activeSession, "links wait until onboarding is finished")
        XCTAssertNotNil(state.notice)

        state.completeOnboarding(goal: .focusBetter)
        state.handle(url: URL(string: "still://start-focus?preset=study")!)
        XCTAssertEqual(state.activeSession?.presetID, .study)
        XCTAssertEqual(state.activeSession?.source, .deepLink)

        state.simulateFocusCard(presetID: .defaultPreset)
        XCTAssertEqual(state.activeSession?.presetID, .study, "a running session is left alone")
        XCTAssertEqual(state.notice?.text, "A session is already running. It's still going.")

        state.endSessionEarly()
        state.simulateFocusCard(presetID: .defaultPreset)
        XCTAssertEqual(state.activeSession?.presetID, .defaultPreset)
        XCTAssertEqual(state.activeSession?.source, .nfcSimulator)
        XCTAssertEqual(state.container.events.recentEvents.filter { $0.name == .nfcPresetRouted }.count, 3)
    }

    func testMuteIsTransientAndEndingEarlyReturnsHome() {
        state.completeOnboarding(goal: .focusBetter)
        state.startFocus()
        state.toggleMute()
        XCTAssertTrue(state.isAudioMuted)
        XCTAssertFalse(state.container.audio.isPlaying)
        state.endSessionEarly()
        XCTAssertFalse(state.isAudioMuted)
        XCTAssertNil(state.activeSession)
        XCTAssertNil(state.router.completion, "ended sessions don't open the completion screen")
        XCTAssertEqual(state.stats.completedSessions, 0)
    }

    func testSceneUnlockIsNoticedOnceThenAcknowledged() {
        state.completeOnboarding(goal: .focusBetter)
        for _ in 0..<7 {
            state.startFocus()
            clock.advance(by: minutes(25))
            state.tick()
            state.returnToFocusFromCompletion()
        }
        XCTAssertEqual(state.newlyUnlockedScenes.map(\.id), [.libraryLight])
        state.acknowledgeUnlockedScenes()
        XCTAssertTrue(state.newlyUnlockedScenes.isEmpty)
    }

    func testResetAllDataReturnsToOnboarding() {
        state.completeOnboarding(goal: .focusBetter)
        state.createTask(title: "Something")
        state.startFocus()
        state.resetAllData()
        XCTAssertFalse(state.preferences.hasCompletedOnboarding)
        XCTAssertNil(state.activeSession)
        XCTAssertTrue(state.todaysTasks.isEmpty)
        XCTAssertTrue(state.sessions.isEmpty)
    }

    func testPreviewStatesBuild() {
        XCTAssertNotNil(PreviewSupport.appState(activeSession: true).activeSession)
        XCTAssertEqual(PreviewSupport.appState(populated: true).stats.completedSessions, 9)
        let completed = PreviewSupport.completedSession()
        XCTAssertEqual(completed.state.suggestions(for: completed.sessionID).activities.count, 3)
    }
}
