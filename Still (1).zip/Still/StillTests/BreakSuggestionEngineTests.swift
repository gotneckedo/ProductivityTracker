import XCTest
#if canImport(StillCore)
@testable import StillCore
#else
@testable import Still
#endif

final class BreakSuggestionEngineTests: XCTestCase {
    let engine = BreakSuggestionEngine()

    func request(
        breakMinutes: Double = 5,
        usedToday: Set<BreakActivityID> = [],
        lastUsed: [BreakActivityID: Date] = [:],
        order: [ActivityCategory] = [.reset, .puzzle, .quiet],
        seed: Int = 0
    ) -> BreakSuggestionRequest {
        BreakSuggestionRequest(
            availableBreak: minutes(breakMinutes),
            catalog: ActivityCatalog.all,
            usedToday: usedToday,
            lastUsedAt: lastUsed,
            categoryOrder: order,
            daySeed: seed
        )
    }

    func testAlwaysExactlyThree() {
        for breakMinutes in [0.5, 1, 2, 5, 10, 30] {
            for seed in 0..<10 {
                let result = engine.suggestions(for: request(breakMinutes: breakMinutes, seed: seed))
                XCTAssertEqual(result.activities.count, 3, "break \(breakMinutes) seed \(seed)")
                XCTAssertEqual(Set(result.activities.map(\.id)).count, 3, "no duplicates")
            }
        }
    }

    func testThreeDifferentCategoriesWhenPossible() {
        let result = engine.suggestions(for: request(breakMinutes: 10))
        XCTAssertEqual(Set(result.activities.map(\.category)).count, 3)
        XCTAssertEqual(result.activities.map(\.category), [.reset, .puzzle, .quiet], "follows personalized order")
    }

    func testPersonalizedOrderChangesFirstCategory() {
        let result = engine.suggestions(for: request(breakMinutes: 10, order: [.puzzle, .quiet, .reset]))
        XCTAssertEqual(result.activities.first?.category, .puzzle)
    }

    func testActivitiesUsedTodayAreSkipped() {
        let used: Set<BreakActivityID> = [.boxBreathing, .brainDump, .sudoku, .shortRead]
        let result = engine.suggestions(for: request(breakMinutes: 10, usedToday: used))
        XCTAssertEqual(result.activities.count, 3)
        XCTAssertTrue(result.activities.allSatisfy { !used.contains($0.id) })
        XCTAssertFalse(result.isRevisit)
    }

    func testShortBreakPrefersActivitiesThatFit() {
        let result = engine.suggestions(for: request(breakMinutes: 2))
        XCTAssertTrue(result.activities.allSatisfy { $0.estimatedDuration <= minutes(2) })
    }

    func testVeryShortBreakFillsWithShortestActivities() {
        let result = engine.suggestions(for: request(breakMinutes: 1))
        XCTAssertEqual(result.activities.count, 3)
        XCTAssertTrue(result.activities.contains { $0.id == .doNothing })
        XCTAssertTrue(result.activities.allSatisfy { $0.estimatedDuration <= minutes(3) })
    }

    func testFallbackWhenEverythingWasUsedToday() {
        let all = Set(ActivityCatalog.all.map(\.id))
        let lastUsed: [BreakActivityID: Date] = [
            .doNothing: referenceDate.addingTimeInterval(-60),
            .boxBreathing: referenceDate.addingTimeInterval(-7200),
            .guidedStretch: referenceDate.addingTimeInterval(-3600)
        ]
        let result = engine.suggestions(for: request(breakMinutes: 2, usedToday: all, lastUsed: lastUsed))
        XCTAssertTrue(result.isRevisit)
        XCTAssertEqual(result.activities.count, 3)
        XCTAssertEqual(result.headline, "You've tried everything today. A few to revisit:")
        // Least recently used first.
        XCTAssertEqual(result.activities.map(\.id), [.boxBreathing, .guidedStretch, .doNothing])
    }

    func testPartialFreshListIsToppedUpWithUsedActivities() {
        let used = Set(ActivityCatalog.all.map(\.id)).subtracting([.picross])
        let result = engine.suggestions(for: request(breakMinutes: 10, usedToday: used))
        XCTAssertEqual(result.activities.count, 3)
        XCTAssertEqual(result.activities.first?.id, .picross)
        XCTAssertFalse(result.isRevisit)
    }

    func testDaySeedRotatesWithinCategory() {
        let dayOne = engine.suggestions(for: request(breakMinutes: 10, seed: 0))
        let dayTwo = engine.suggestions(for: request(breakMinutes: 10, seed: 1))
        XCTAssertNotEqual(dayOne.activities.map(\.id), dayTwo.activities.map(\.id))
    }

    func testPlannedActivitiesAreNeverSuggested() {
        var catalog = ActivityCatalog.all
        catalog.append(BreakActivity(id: BreakActivityID("doodle"), name: "Doodle", category: .quiet, summary: "",
                                     estimatedDuration: 60, implementationState: .planned, symbolName: "pencil", sortOrder: -1))
        var req = request(breakMinutes: 10, order: [.quiet])
        req.catalog = catalog
        let result = engine.suggestions(for: req)
        XCTAssertFalse(result.activities.contains { $0.id == BreakActivityID("doodle") })
    }

    func testControllerUsesSessionBreakAndUsageHistory() {
        let clock = ManualClock(referenceDate)
        let container = makeContainer(clock: clock)
        container.breaks.begin(.boxBreathing, context: .shelf)
        let session = makeSession(.pomodoro(focus: 25, rest: 2, cycles: 2))
        let result = container.breaks.suggestions(after: session, personalization: Personalization(goal: .calmerPhone), trackPresentation: false)
        XCTAssertEqual(result.availableBreak, minutes(2))
        XCTAssertFalse(result.activities.contains { $0.id == .boxBreathing }, "a fresh activity beats a repeat")
        XCTAssertEqual(result.activities.count, 3)
        XCTAssertFalse(result.isRevisit)
    }
}
