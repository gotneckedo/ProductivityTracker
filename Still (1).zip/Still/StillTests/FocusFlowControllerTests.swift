import XCTest
#if canImport(StillCore)
@testable import StillCore
#else
@testable import Still
#endif

final class FocusFlowControllerTests: XCTestCase {
    var clock: ManualClock!
    var notifications: RecordingNotificationScheduler!
    var container: DependencyContainer!

    override func setUp() {
        super.setUp()
        clock = ManualClock(referenceDate)
        notifications = RecordingNotificationScheduler(authorization: .granted)
        container = makeContainer(clock: clock, notifications: notifications)
        container.preferences.completeOnboarding(goal: .focusBetter)
    }

    // MARK: Completion vs abandonment

    func testCompletedSessionCountsAndOpensCompletionMoment() {
        let outcome = container.focus.start(presetID: .defaultPreset, taskID: nil, source: .manual)
        guard case .started(let session) = outcome else { return XCTFail("expected start") }

        clock.advance(by: minutes(25))
        let events = container.focus.tick()

        XCTAssertEqual(events, [.sessionCompleted(session.id)])
        XCTAssertNil(container.focus.activeSession)
        XCTAssertEqual(container.sessions.session(id: session.id)?.state, .completed)
        XCTAssertEqual(container.focus.completedSessionCount, 1)
        XCTAssertEqual(container.preferencesStore.load().pendingCompletionSessionID, session.id)
        XCTAssertTrue(notifications.scheduled.isEmpty, "reminders are cleared at completion")
    }

    func testEndingEarlyIsAbandonedAndGrantsNoProgress() {
        container.focus.start(presetID: .defaultPreset, taskID: nil, source: .manual)
        clock.advance(by: minutes(20))
        let event = container.focus.endEarly()

        guard case .sessionAbandoned(let id)? = event else { return XCTFail("expected abandoned") }
        XCTAssertEqual(container.sessions.session(id: id)?.state, .abandoned)
        XCTAssertEqual(container.focus.completedSessionCount, 0)
        XCTAssertNil(container.preferencesStore.load().pendingCompletionSessionID)

        let stats = StatsCalculator(calendar: testCalendar).stats(
            sessions: container.sessions.allSessions(), usages: [], now: clock.now)
        XCTAssertEqual(stats.completedSessions, 0)
        XCTAssertEqual(stats.totalFocus, 0)
        XCTAssertEqual(stats.currentStreak, 0)
    }

    func testPauseResumePersistsAndReschedules() {
        container.focus.start(presetID: .defaultPreset, taskID: nil, source: .manual)
        XCTAssertEqual(notifications.scheduled.count, 1)

        clock.advance(by: minutes(5))
        container.focus.pause()
        XCTAssertEqual(container.sessions.liveSession()?.state, .paused)
        XCTAssertTrue(notifications.scheduled.isEmpty)
        XCTAssertFalse(container.audio.isPlaying)

        clock.advance(by: minutes(30))
        container.focus.resume()
        XCTAssertEqual(container.sessions.liveSession()?.state, .active)
        XCTAssertEqual(notifications.scheduled.first?.date, clock.now.addingTimeInterval(minutes(20)))
        XCTAssertEqual(container.focus.snapshot()?.remainingInPhase, minutes(20))
    }

    // MARK: Relaunch

    func testRestoreAfterRelaunchCompletesOverdueSession() {
        container.focus.start(presetID: .defaultPreset, taskID: nil, source: .manual)
        let sessionID = container.focus.activeSession!.id

        // Simulate a cold launch 40 minutes later: a new controller, same storage.
        clock.advance(by: minutes(40))
        let relaunched = DependencyContainer(
            clock: clock, calendar: testCalendar,
            recordStore: container.recordStore, keyValueStore: container.keyValueStore,
            notifications: notifications, audio: SilentAmbientAudioPlayer(),
            blocking: MockFocusBlockingService(), liveActivity: NoopLiveActivityUpdater()
        )
        let events = relaunched.focus.restore()
        XCTAssertEqual(events, [.sessionCompleted(sessionID)])
        let stored = relaunched.sessions.session(id: sessionID)
        XCTAssertEqual(stored?.endedAt, referenceDate.addingTimeInterval(minutes(25)))
        XCTAssertEqual(relaunched.preferencesStore.load().pendingCompletionSessionID, sessionID)
    }

    func testRestoreKeepsPausedSessionPaused() {
        container.focus.start(presetID: .defaultPreset, taskID: nil, source: .manual)
        clock.advance(by: minutes(10))
        container.focus.pause()

        clock.advance(by: minutes(300))
        let relaunched = DependencyContainer(
            clock: clock, calendar: testCalendar,
            recordStore: container.recordStore, keyValueStore: container.keyValueStore,
            notifications: notifications, audio: SilentAmbientAudioPlayer(),
            blocking: MockFocusBlockingService(), liveActivity: NoopLiveActivityUpdater()
        )
        XCTAssertTrue(relaunched.focus.restore().isEmpty)
        XCTAssertEqual(relaunched.focus.snapshot()?.state, .paused)
        XCTAssertEqual(relaunched.focus.snapshot()?.remainingInPhase, minutes(15))
    }

    // MARK: Tasks

    func testTaskIsAttachedToSessionAndCountedOnCompletion() {
        let task = container.taskController.create(title: "  Biology   homework ")!
        XCTAssertEqual(task.title, "Biology homework")

        let outcome = container.focus.start(presetID: .defaultPreset, taskID: task.id, source: .manual)
        XCTAssertEqual(outcome.session.taskID, task.id)
        XCTAssertEqual(container.tasks.task(id: task.id)?.attachedSessionID, outcome.session.id)

        clock.advance(by: minutes(25))
        container.focus.tick()
        let updated = container.tasks.task(id: task.id)!
        XCTAssertEqual(updated.completedSessionCount, 1)
        XCTAssertFalse(updated.isCompleted, "finishing a session does not mark the task done")

        container.taskController.setCompleted(id: task.id, true)
        XCTAssertTrue(container.tasks.task(id: task.id)!.isCompleted)
    }

    func testCompletedTaskIsNotAttachedToNewSession() {
        let task = container.taskController.create(title: "Done already")!
        container.taskController.setCompleted(id: task.id, true)
        let outcome = container.focus.start(presetID: .defaultPreset, taskID: task.id, source: .manual)
        XCTAssertNil(outcome.session.taskID)
    }

    func testAbandonedSessionDoesNotCountForTask() {
        let task = container.taskController.create(title: "Essay")!
        container.focus.start(presetID: .defaultPreset, taskID: task.id, source: .manual)
        clock.advance(by: minutes(3))
        container.focus.endEarly()
        XCTAssertEqual(container.tasks.task(id: task.id)?.completedSessionCount, 0)
    }

    func testBlankTaskTitleIsRejected() {
        XCTAssertNil(container.taskController.create(title: "   \n "))
        XCTAssertTrue(container.tasks.allTasks().isEmpty)
    }

    func testTodaysTasksShowsOpenThenDoneToday() {
        let a = container.taskController.create(title: "A")!
        clock.advance(by: 60)
        let b = container.taskController.create(title: "B")!
        container.taskController.setCompleted(id: a.id, true)
        XCTAssertEqual(container.taskController.todaysTasks().map(\.id), [b.id, a.id])

        clock.advance(by: 2 * 86_400)
        XCTAssertEqual(container.taskController.todaysTasks().map(\.id), [b.id], "done tasks from other days drop off")
    }

    // MARK: Presets and routing

    func testStudyPresetStartsPomodoroInCalmMode() {
        let outcome = container.focus.start(presetID: .study, taskID: nil, source: .deepLink)
        XCTAssertEqual(outcome.session.configuration.mode, .pomodoro)
        XCTAssertEqual(outcome.session.configuration.focusDuration, minutes(50))
        XCTAssertEqual(outcome.session.renderMode, .calm)
        XCTAssertEqual(outcome.session.presetID, .study)
        XCTAssertEqual((container.blocking as? MockFocusBlockingService)?.recordedIntents[outcome.session.id], .soft)
        XCTAssertFalse(container.blocking.isShielding, "the V1 mock never claims to shield apps")
    }

    func testUnknownPresetFallsBackToDefault() {
        let outcome = container.focus.start(presetID: FocusPresetID("nope"), taskID: nil, source: .deepLink)
        guard case .startedWithFallback(let session, let requested) = outcome else { return XCTFail() }
        XCTAssertEqual(session.presetID, .defaultPreset)
        XCTAssertEqual(requested, FocusPresetID("nope"))
    }

    func testSecondStartLeavesRunningSessionAlone() {
        let first = container.focus.start(presetID: .defaultPreset, taskID: nil, source: .manual).session
        let second = container.focus.start(presetID: .study, taskID: nil, source: .nfcSimulator)
        XCTAssertEqual(second, .alreadyRunning(first))
        XCTAssertEqual(container.sessions.allSessions().count, 1)
    }

    func testLockedSceneFallsBackToUnlockedScene() {
        var preset = container.preferences.preset(.defaultPreset)
        preset.sceneID = .nightCity
        container.preferences.save(preset)
        let session = container.focus.start(presetID: .defaultPreset, taskID: nil, source: .manual).session
        XCTAssertEqual(session.sceneID, .rainyBedroom)
    }

    // MARK: Notifications

    func testNotificationPermissionDeniedStillCompletesInApp() async {
        let denied = RecordingNotificationScheduler(authorization: .notDetermined, grantsOnRequest: false)
        let container = makeContainer(clock: clock, notifications: denied)
        container.preferences.completeOnboarding(goal: .scrollLess)

        let session = container.focus.start(presetID: .defaultPreset, taskID: nil, source: .manual).session
        let granted = await container.focus.requestNotificationPermissionIfNeeded()
        XCTAssertFalse(granted)
        XCTAssertTrue(denied.scheduled.isEmpty)
        XCTAssertEqual(container.preferencesStore.load().notificationPermissionGranted, false)
        XCTAssertEqual(container.events.recentEvents.last?.name, .notificationPermissionResult)

        // Asked only once.
        _ = await container.focus.requestNotificationPermissionIfNeeded()
        XCTAssertEqual(denied.requestCount, 1)

        clock.advance(by: minutes(25))
        XCTAssertEqual(container.focus.tick(), [.sessionCompleted(session.id)])
    }

    func testGrantedPermissionSchedulesPhaseEnd() async {
        let fresh = RecordingNotificationScheduler(authorization: .notDetermined, grantsOnRequest: true)
        let container = makeContainer(clock: clock, notifications: fresh)
        container.focus.start(presetID: .defaultPreset, taskID: nil, source: .manual)
        XCTAssertTrue(fresh.scheduled.isEmpty, "nothing scheduled before permission")
        _ = await container.focus.requestNotificationPermissionIfNeeded()
        XCTAssertEqual(fresh.scheduled.map(\.date), [referenceDate.addingTimeInterval(minutes(25))])
    }

    // MARK: Events

    func testFunnelEventsAreRecordedInOrder() {
        let session = container.focus.start(presetID: .defaultPreset, taskID: nil, source: .manual).session
        clock.advance(by: minutes(25))
        container.focus.tick()
        let suggestions = container.breaks.suggestions(after: container.sessions.session(id: session.id),
                                                       personalization: Personalization(goal: .focusBetter),
                                                       trackPresentation: true)
        let usage = container.breaks.begin(suggestions.activities[0].id,
                                           context: ActivityContext(entryPoint: .suggestion, sessionID: session.id, suggestionRank: 0))
        clock.advance(by: 90)
        container.breaks.finish(usageID: usage.id, outcome: .completed)
        container.focus.acknowledgeCompletion(returningToFocus: true)

        let names = container.events.recentEvents.map(\.name)
        XCTAssertEqual(names, [
            .onboardingCompleted, .focusStarted, .focusCompleted, .breakSuggestionsPresented,
            .breakActivityStarted, .breakActivityCompleted, .returnedToFocus
        ])
    }
}
