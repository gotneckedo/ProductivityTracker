import XCTest
#if canImport(StillCore)
@testable import StillCore
#else
@testable import Still
#endif

final class FocusTimerEngineTests: XCTestCase {
    let engine = FocusTimerEngine()

    // MARK: Countdown

    func testCountdownRemainingDerivesFromDates() {
        let session = makeSession(.countdown(25))
        let snapshot = engine.snapshot(of: session, at: referenceDate.addingTimeInterval(minutes(10)))
        XCTAssertEqual(snapshot.remainingInPhase, minutes(15))
        XCTAssertEqual(snapshot.elapsedInPhase, minutes(10))
        XCTAssertEqual(snapshot.phaseEndDate, referenceDate.addingTimeInterval(minutes(25)))
        XCTAssertEqual(snapshot.phaseProgress!, 0.4, accuracy: 0.0001)
        XCTAssertTrue(snapshot.isRunning)
    }

    func testCountdownCompletesAtExactEndDateEvenWhenCheckedLate() {
        let session = makeSession(.countdown(25))
        // App was in the background for two hours.
        let (advanced, transitions) = engine.advance(session, to: referenceDate.addingTimeInterval(minutes(120)))
        XCTAssertEqual(advanced.state, .completed)
        XCTAssertEqual(advanced.endedAt, referenceDate.addingTimeInterval(minutes(25)))
        XCTAssertEqual(advanced.completedFocusDuration, minutes(25))
        XCTAssertEqual(transitions.last, .sessionCompleted(at: referenceDate.addingTimeInterval(minutes(25))))
    }

    func testCountdownNotCompleteOneSecondEarly() {
        let session = makeSession(.countdown(25))
        let (advanced, transitions) = engine.advance(session, to: referenceDate.addingTimeInterval(minutes(25) - 1))
        XCTAssertEqual(advanced.state, .active)
        XCTAssertTrue(transitions.isEmpty)
    }

    // MARK: Pause / resume

    func testPauseFreezesAndResumeContinues() {
        var session = makeSession(.countdown(25))
        session = engine.pause(session, at: referenceDate.addingTimeInterval(minutes(5))).0
        XCTAssertEqual(session.state, .paused)
        XCTAssertEqual(session.pauseCount, 1)

        // Paused for an hour: remaining time does not move.
        let whilePaused = engine.snapshot(of: session, at: referenceDate.addingTimeInterval(minutes(65)))
        XCTAssertEqual(whilePaused.remainingInPhase, minutes(20))
        XCTAssertNil(whilePaused.phaseEndDate)
        XCTAssertTrue(whilePaused.isPaused)

        session = engine.resume(session, at: referenceDate.addingTimeInterval(minutes(65)))
        let after = engine.snapshot(of: session, at: referenceDate.addingTimeInterval(minutes(70)))
        XCTAssertEqual(after.remainingInPhase, minutes(15))
        XCTAssertEqual(after.phaseEndDate, referenceDate.addingTimeInterval(minutes(85)))

        let (done, _) = engine.advance(session, to: referenceDate.addingTimeInterval(minutes(90)))
        XCTAssertEqual(done.state, .completed)
        XCTAssertEqual(done.endedAt, referenceDate.addingTimeInterval(minutes(85)))
    }

    func testPausedSessionNeverCompletesOnItsOwn() {
        var session = makeSession(.countdown(25))
        session = engine.pause(session, at: referenceDate.addingTimeInterval(minutes(24))).0
        let (advanced, transitions) = engine.advance(session, to: referenceDate.addingTimeInterval(minutes(600)))
        XCTAssertEqual(advanced.state, .paused)
        XCTAssertTrue(transitions.isEmpty)
    }

    func testPauseAfterEndCompletesInstead() {
        let session = makeSession(.countdown(25))
        let (result, transitions) = engine.pause(session, at: referenceDate.addingTimeInterval(minutes(30)))
        XCTAssertEqual(result.state, .completed)
        XCTAssertTrue(transitions.contains(.sessionCompleted(at: referenceDate.addingTimeInterval(minutes(25)))))
    }

    func testResumeSurvivesEncodeDecodeLikeAProcessRestart() throws {
        var session = makeSession(.countdown(25))
        session = engine.pause(session, at: referenceDate.addingTimeInterval(minutes(8))).0
        let data = try RecordCoding.encoder().encode(session)
        let restored = try RecordCoding.decoder().decode(FocusSession.self, from: data)
        XCTAssertEqual(restored, session)
        let resumed = engine.resume(restored, at: referenceDate.addingTimeInterval(minutes(30)))
        XCTAssertEqual(engine.snapshot(of: resumed, at: referenceDate.addingTimeInterval(minutes(30))).remainingInPhase, minutes(17))
    }

    // MARK: Count-up

    func testCountUpRunsOpenEnded() {
        let session = makeSession(.countUp)
        let snapshot = engine.snapshot(of: session, at: referenceDate.addingTimeInterval(minutes(300)))
        XCTAssertEqual(snapshot.state, .active)
        XCTAssertNil(snapshot.remainingInPhase)
        XCTAssertNil(snapshot.phaseProgress)
        XCTAssertEqual(snapshot.displayedSeconds, minutes(300))
        XCTAssertEqual(snapshot.totalFocusElapsed, minutes(300))
    }

    func testCountUpFinishAboveThresholdCompletes() {
        var session = makeSession(.countUp)
        session = engine.pause(session, at: referenceDate.addingTimeInterval(minutes(10))).0
        session = engine.resume(session, at: referenceDate.addingTimeInterval(minutes(20)))
        let finished = engine.finishCountUp(session, at: referenceDate.addingTimeInterval(minutes(32)))
        XCTAssertEqual(finished.state, .completed)
        XCTAssertEqual(finished.completedFocusDuration, minutes(22), "paused time is excluded")
        XCTAssertEqual(finished.countedFocusDuration, minutes(22))
    }

    func testCountUpFinishBelowThresholdIsAbandoned() {
        let session = makeSession(.countUp)
        let finished = engine.finishCountUp(session, at: referenceDate.addingTimeInterval(minutes(4)))
        XCTAssertEqual(finished.state, .abandoned)
        XCTAssertEqual(finished.countedFocusDuration, 0)
    }

    // MARK: Pomodoro

    func testPomodoroPhasePlan() {
        let configuration = TimerConfiguration.pomodoro(focus: 25, rest: 5, cycles: 3)
        XCTAssertEqual(configuration.phases.map(\.kind), [.focus, .shortBreak, .focus, .shortBreak, .focus])
        XCTAssertEqual(configuration.focusBlockCount, 3)
        XCTAssertEqual(configuration.plannedFocusDuration, minutes(75))
    }

    func testPomodoroLongBreakInterval() {
        var configuration = TimerConfiguration.pomodoro(focus: 25, rest: 5, cycles: 5)
        configuration.longBreakInterval = 2
        XCTAssertEqual(configuration.phases.map(\.kind),
                       [.focus, .shortBreak, .focus, .longBreak, .focus, .shortBreak, .focus, .longBreak, .focus])
    }

    func testPomodoroAutoAdvancesThroughPhasesInBackground() {
        let session = makeSession(.pomodoro(focus: 25, rest: 5, cycles: 2))
        // Mid-way through the second focus block.
        let snapshot = engine.snapshot(of: session, at: referenceDate.addingTimeInterval(minutes(40)))
        XCTAssertEqual(snapshot.phaseKind, .focus)
        XCTAssertEqual(snapshot.phaseIndex, 2)
        XCTAssertEqual(snapshot.focusBlockNumber, 2)
        XCTAssertEqual(snapshot.remainingInPhase, minutes(15))
        XCTAssertEqual(snapshot.totalFocusElapsed, minutes(35))

        let (done, transitions) = engine.advance(session, to: referenceDate.addingTimeInterval(minutes(90)))
        XCTAssertEqual(done.state, .completed)
        XCTAssertEqual(done.endedAt, referenceDate.addingTimeInterval(minutes(55)))
        XCTAssertEqual(done.completedFocusDuration, minutes(50))
        XCTAssertEqual(done.completedFocusPhases, 2)
        XCTAssertEqual(transitions, [
            .phaseCompleted(index: 0, kind: .focus, at: referenceDate.addingTimeInterval(minutes(25))),
            .phaseStarted(index: 1, kind: .shortBreak, at: referenceDate.addingTimeInterval(minutes(25))),
            .phaseCompleted(index: 1, kind: .shortBreak, at: referenceDate.addingTimeInterval(minutes(30))),
            .phaseStarted(index: 2, kind: .focus, at: referenceDate.addingTimeInterval(minutes(30))),
            .phaseCompleted(index: 2, kind: .focus, at: referenceDate.addingTimeInterval(minutes(55))),
            .sessionCompleted(at: referenceDate.addingTimeInterval(minutes(55)))
        ])
    }

    func testPomodoroWaitsWhenAutoStartIsOff() {
        var session = makeSession(.pomodoro(focus: 25, rest: 5, cycles: 2, autoBreaks: true, autoFocus: false))
        let (waiting, transitions) = engine.advance(session, to: referenceDate.addingTimeInterval(minutes(45)))
        XCTAssertTrue(waiting.isAwaitingNextPhase)
        XCTAssertEqual(transitions.last, .awaitingNextPhase(nextIndex: 2, kind: .focus))

        // Waiting does not consume time.
        let later = engine.snapshot(of: waiting, at: referenceDate.addingTimeInterval(minutes(120)))
        XCTAssertEqual(later.phaseKind, .shortBreak)
        XCTAssertEqual(later.remainingInPhase, 0)
        XCTAssertEqual(later.nextPhaseKind, .focus)
        XCTAssertNil(later.phaseEndDate)
        XCTAssertEqual(later.totalFocusElapsed, minutes(25))

        session = engine.startNextPhase(waiting, at: referenceDate.addingTimeInterval(minutes(120))).0
        let running = engine.snapshot(of: session, at: referenceDate.addingTimeInterval(minutes(130)))
        XCTAssertEqual(running.phaseKind, .focus)
        XCTAssertEqual(running.remainingInPhase, minutes(15))
        XCTAssertEqual(running.totalFocusElapsed, minutes(35))
    }

    func testSkipBreakStartsNextFocusImmediately() {
        let session = makeSession(.pomodoro(focus: 25, rest: 5, cycles: 2))
        let (skipped, _) = engine.skipBreak(session, at: referenceDate.addingTimeInterval(minutes(26)))
        XCTAssertEqual(skipped.phaseIndex, 2)
        let snapshot = engine.snapshot(of: skipped, at: referenceDate.addingTimeInterval(minutes(36)))
        XCTAssertEqual(snapshot.phaseKind, .focus)
        XCTAssertEqual(snapshot.remainingInPhase, minutes(15))
    }

    func testSkipBreakIsIgnoredDuringFocus() {
        let session = makeSession(.pomodoro(focus: 25, rest: 5, cycles: 2))
        let (result, transitions) = engine.skipBreak(session, at: referenceDate.addingTimeInterval(minutes(10)))
        XCTAssertEqual(result.phaseIndex, 0)
        XCTAssertTrue(transitions.isEmpty)
    }

    // MARK: Abandonment

    func testAbandonEarlyMarksAbandonedWithoutProgress() {
        let session = makeSession(.pomodoro(focus: 25, rest: 5, cycles: 2))
        let ended = engine.abandon(session, at: referenceDate.addingTimeInterval(minutes(40)))
        XCTAssertEqual(ended.state, .abandoned)
        XCTAssertEqual(ended.endedAt, referenceDate.addingTimeInterval(minutes(40)))
        XCTAssertEqual(ended.countedFocusDuration, 0, "abandoned sessions never count")
    }

    func testAbandonAfterNaturalEndKeepsCompletion() {
        let session = makeSession(.countdown(25))
        let ended = engine.abandon(session, at: referenceDate.addingTimeInterval(minutes(26)))
        XCTAssertEqual(ended.state, .completed)
    }

    // MARK: Boundaries for notifications

    func testUpcomingBoundariesFollowAutoStart() {
        let session = makeSession(.pomodoro(focus: 25, rest: 5, cycles: 3, autoBreaks: true, autoFocus: false))
        let boundaries = engine.upcomingBoundaries(session, from: referenceDate.addingTimeInterval(minutes(1)))
        XCTAssertEqual(boundaries.count, 2)
        XCTAssertEqual(boundaries[0].date, referenceDate.addingTimeInterval(minutes(25)))
        XCTAssertEqual(boundaries[0].nextKind, .shortBreak)
        XCTAssertFalse(boundaries[0].requiresUserToContinue)
        XCTAssertEqual(boundaries[1].date, referenceDate.addingTimeInterval(minutes(30)))
        XCTAssertTrue(boundaries[1].requiresUserToContinue)
    }

    func testUpcomingBoundariesEndWithSession() {
        let session = makeSession(.pomodoro(focus: 25, rest: 5, cycles: 2))
        let boundaries = engine.upcomingBoundaries(session, from: referenceDate)
        XCTAssertEqual(boundaries.map(\.endsSession), [false, false, true])
        XCTAssertEqual(boundaries.last?.date, referenceDate.addingTimeInterval(minutes(55)))
    }

    func testNoBoundariesWhilePausedOrCountingUp() {
        let paused = engine.pause(makeSession(.countdown(25)), at: referenceDate).0
        XCTAssertTrue(engine.upcomingBoundaries(paused, from: referenceDate).isEmpty)
        XCTAssertTrue(engine.upcomingBoundaries(makeSession(.countUp), from: referenceDate).isEmpty)
    }

    // MARK: Configuration

    func testValidationClampsValues() {
        var configuration = TimerConfiguration.standard
        configuration.focusDuration = 10
        configuration.breakDuration = minutes(500)
        configuration.cycleCount = 40
        let validated = configuration.validated()
        XCTAssertEqual(validated.focusDuration, TimerConfiguration.focusRange.lowerBound)
        XCTAssertEqual(validated.breakDuration, TimerConfiguration.breakRange.upperBound)
        XCTAssertEqual(validated.cycleCount, TimerConfiguration.cycleRange.upperBound)
    }

    func testDurationFormatting() {
        XCTAssertEqual(DurationFormatter.clock(minutes(25)), "25:00")
        XCTAssertEqual(DurationFormatter.clock(59.2), "01:00")
        XCTAssertEqual(DurationFormatter.clock(3725), "1:02:05")
        XCTAssertEqual(DurationFormatter.elapsedClock(0.9), "00:00")
        XCTAssertEqual(DurationFormatter.short(minutes(65)), "1 h 5 min")
        XCTAssertEqual(DurationFormatter.spoken(minutes(12) + 30), "12 minutes 30 seconds")
    }
}
