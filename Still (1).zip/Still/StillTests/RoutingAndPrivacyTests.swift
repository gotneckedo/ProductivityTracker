import XCTest
#if canImport(StillCore)
@testable import StillCore
#else
@testable import Still
#endif

final class DeepLinkTests: XCTestCase {
    let parser = DeepLinkParser()

    func testDefaultPresetLink() {
        XCTAssertEqual(parser.parse(URL(string: "still://start-focus?preset=default")!), .startFocus(presetID: .defaultPreset))
    }

    func testStudyPresetLink() {
        XCTAssertEqual(parser.parse(URL(string: "still://start-focus?preset=study")!), .startFocus(presetID: .study))
    }

    func testMissingPresetMeansDefault() {
        XCTAssertEqual(parser.parse(URL(string: "still://start-focus")!), .startFocus(presetID: .defaultPreset))
    }

    func testPathStyleAndCaseInsensitiveAction() {
        XCTAssertEqual(parser.parse(URL(string: "still:///start-focus?preset=study")!), .startFocus(presetID: .study))
        XCTAssertEqual(parser.parse(URL(string: "STILL://Start-Focus?preset=study")!), .startFocus(presetID: .study))
    }

    func testRejectsOtherSchemesActionsAndHostileValues() {
        XCTAssertNil(parser.parse(URL(string: "https://example.com/start-focus?preset=study")!))
        XCTAssertNil(parser.parse(URL(string: "still://delete-everything")!))
        XCTAssertNil(parser.parse(URL(string: "still://start-focus?preset=%3Cscript%3E")!))
        XCTAssertNil(parser.parse(URL(string: "still://start-focus?preset=" + String(repeating: "a", count: 41))!))
    }

    func testUniversalLinkHostsAreOptIn() {
        var withHost = DeepLinkParser()
        withHost.universalLinkHosts = ["focus.example.com"]
        XCTAssertEqual(withHost.parse(URL(string: "https://focus.example.com/start-focus?preset=study")!), .startFocus(presetID: .study))
    }

    func testPresetURLRoundTrips() {
        for preset in [PresetCatalog.defaultPreset(), PresetCatalog.study] {
            XCTAssertEqual(parser.parse(preset.startURL), .startFocus(presetID: preset.id))
        }
        XCTAssertEqual(PresetCatalog.study.startURL.absoluteString, "still://start-focus?preset=study")
    }

    func testNFCRouterRecognizesKnownPresets() {
        let router = DeepLinkPresetRouter(knownPresetIDs: [.defaultPreset, .study])
        XCTAssertEqual(router.route(URL(string: "still://start-focus?preset=study")!), .startPreset(.study))
        XCTAssertEqual(router.route(URL(string: "still://start-focus?preset=deepWork")!), .unknownPreset(FocusPresetID("deepWork")))
        XCTAssertEqual(router.route(URL(string: "still://settings")!), .notAFocusLink)
    }
}

final class RouteResolverTests: XCTestCase {
    func testCoreLoopRoutes() {
        let resolver = RouteResolver(flags: .v1)
        let id = UUID()
        XCTAssertEqual(resolver.destination(for: .sessionComplete(id), currentTab: .me).completionSessionID, id)
        XCTAssertEqual(resolver.destination(for: .sessionComplete(id), currentTab: .me).tab, .focus)

        let activity = AppRoute.breakActivity(.sudoku, ActivityContext(entryPoint: .suggestion, sessionID: id, suggestionRank: 1))
        let destination = resolver.destination(for: activity, currentTab: .focus)
        XCTAssertEqual(destination.tab, .breakShelf)
        XCTAssertEqual(destination.stack, [activity])

        XCTAssertEqual(resolver.destination(for: .breakShelf, currentTab: .focus), RouteDestination(tab: .breakShelf, stack: [], sheet: nil, completionSessionID: nil))
        XCTAssertEqual(resolver.destination(for: .focusHome, currentTab: .breakShelf).tab, .focus)
        XCTAssertEqual(resolver.destination(for: .focusConfiguration, currentTab: .focus).sheet, .focusConfiguration)
        XCTAssertEqual(resolver.destination(for: .tasks, currentTab: .me).tab, .me)
        XCTAssertEqual(resolver.destination(for: .nfcSetup, currentTab: .focus).stack, [.nfcSetup])
    }

    func testJournalIsHiddenInV1AndReadyBehindFlag() {
        XCTAssertEqual(AppTab.visibleTabs(flags: .v1), [.focus, .breakShelf, .me])
        XCTAssertEqual(RouteResolver(flags: .v1).destination(for: .journal, currentTab: .focus).tab, .me)

        var flags = FeatureFlags.v1
        flags.journalTab = true
        XCTAssertEqual(AppTab.visibleTabs(flags: flags), [.focus, .breakShelf, .journal, .me])
        XCTAssertEqual(RouteResolver(flags: flags).destination(for: .journal, currentTab: .focus).tab, .journal)
    }
}

final class EventPrivacyTests: XCTestCase {
    func testSanitizerRedactsFreeText() {
        XCTAssertEqual(EventProperties.sanitizedToken("Biology homework"), SafeToken.redacted)
        XCTAssertEqual(EventProperties.sanitizedToken("call mom @ 5"), SafeToken.redacted)
        XCTAssertEqual(EventProperties.sanitizedToken(String(repeating: "a", count: 40)), SafeToken.redacted)
        XCTAssertEqual(EventProperties.sanitizedToken(""), SafeToken.redacted)
        XCTAssertEqual(EventProperties.sanitizedToken("pomodoro"), "pomodoro")
        XCTAssertEqual(EventProperties.sanitizedToken("wordSearch"), "wordSearch")
    }

    func testUnknownIdentifiersAreAnonymized() {
        let props = EventProperties()
            .preset(FocusPresetID("Emma's secret plan"))
            .activity(BreakActivityID("my diary"))
        XCTAssertEqual(props.values[.presetID]?.description, "custom")
        XCTAssertEqual(props.values[.activityID]?.description, "custom")
    }

    func testDurationsAreBucketed() {
        XCTAssertEqual(EventProperties.bucket(for: 30), "under_1m")
        XCTAssertEqual(EventProperties.bucket(for: minutes(25)), "m15_30")
        XCTAssertEqual(EventProperties.bucket(for: minutes(90)), "over_60m")
    }

    func testPrivateTextNeverReachesTheEventLog() {
        let clock = ManualClock(referenceDate)
        let container = makeContainer(clock: clock)
        container.preferences.completeOnboarding(goal: .scrollLess)
        let secret = "Biology homework"
        let noteText = "I am worried about the exam"

        let task = container.taskController.create(title: secret)!
        let session = container.focus.start(presetID: .defaultPreset, taskID: task.id, source: .manual).session
        clock.advance(by: minutes(25))
        container.focus.tick()
        let usage = container.breaks.begin(.brainDump, context: ActivityContext(entryPoint: .suggestion, sessionID: session.id, suggestionRank: 2))
        container.breaks.saveNote(text: noteText, kind: .brainDump, activityID: .brainDump, promptID: nil)
        container.breaks.finish(usageID: usage.id, outcome: .completed)

        let allValues = container.events.recentEvents.flatMap { event in event.properties.values.values.map(\.description) }
        XCTAssertFalse(allValues.isEmpty)
        for value in allValues {
            XCTAssertFalse(value.contains("Biology"), "task title leaked: \(value)")
            XCTAssertFalse(value.contains("worried"), "note text leaked: \(value)")
            XCTAssertTrue(SafeToken.isSafe(value) || Int(value) != nil || value == "true" || value == "false")
        }
    }
}

final class LiveActivityAndNotificationTests: XCTestCase {
    func testLiveActivityMappingOmitsTaskAndReflectsState() {
        let engine = FocusTimerEngine()
        let session = makeSession(.countdown(25))
        let running = engine.snapshot(of: session, at: referenceDate.addingTimeInterval(60))
        let state = LiveActivityMapper.state(for: running, sceneName: "Rainy Bedroom", now: referenceDate.addingTimeInterval(60))!
        XCTAssertEqual(state.headline, "Focus")
        XCTAssertEqual(state.phaseEndDate, referenceDate.addingTimeInterval(minutes(25)))
        XCTAssertNil(state.frozenSeconds)

        let paused = engine.pause(session, at: referenceDate.addingTimeInterval(120)).0
        let pausedState = LiveActivityMapper.state(for: engine.snapshot(of: paused, at: referenceDate.addingTimeInterval(500)),
                                                   sceneName: "Rainy Bedroom", now: referenceDate.addingTimeInterval(500))!
        XCTAssertEqual(pausedState.headline, "Paused")
        XCTAssertNil(pausedState.phaseEndDate)
        XCTAssertEqual(pausedState.frozenSeconds, minutes(25) - 120)

        let done = engine.advance(session, to: referenceDate.addingTimeInterval(minutes(30))).0
        XCTAssertNil(LiveActivityMapper.state(for: engine.snapshot(of: done, at: referenceDate), sceneName: "", now: referenceDate))
    }

    func testNotificationCopyIsCalm() {
        let boundaries = FocusTimerEngine().upcomingBoundaries(
            makeSession(.pomodoro(focus: 25, rest: 5, cycles: 2, autoBreaks: true, autoFocus: false)), from: referenceDate)
        let copy = boundaries.map { NotificationCopy.content(for: $0) }
        XCTAssertEqual(copy.first?.title, "Focus block done")
        XCTAssertEqual(copy.last?.title, "Break's over")
        let session = FocusTimerEngine().upcomingBoundaries(makeSession(.countdown(25)), from: referenceDate)
        XCTAssertEqual(NotificationCopy.content(for: session[0]).title, "Session complete")
        for (title, body) in copy {
            XCTAssertFalse(title.contains("!") || body.contains("!"))
        }
    }

    func testBlockingCopyNeverClaimsShieldingInV1() {
        let mock = MockFocusBlockingService()
        XCTAssertEqual(BlockingCopy.title(for: mock.capability, isShielding: mock.isShielding), "Blocking setup is ready")
        XCTAssertFalse(BlockingCopy.detail(for: mock.capability).lowercased().contains("apps are blocked"))
    }

    func testAmbientSummaryLine() {
        var mix = AmbientMix.silent
        XCTAssertEqual(mix.summaryLine, "Sound off")
        mix.isEnabled = true
        mix.setLevel(0.7, for: .rain)
        XCTAssertEqual(mix.summaryLine, "Rain · 42%")
        mix.setLevel(0.3, for: .cafe)
        XCTAssertEqual(mix.summaryLine, "Rain + Café · 42%")
        mix.setMasterVolume(0)
        XCTAssertEqual(mix.summaryLine, "Sound off")
        XCTAssertEqual(mix.effectiveVolume(for: .rain), 0)
    }
}
