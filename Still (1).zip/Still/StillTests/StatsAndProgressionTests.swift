import XCTest
#if canImport(StillCore)
@testable import StillCore
#else
@testable import Still
#endif

final class StreakTests: XCTestCase {
    let streaks = StreakCalculator(calendar: testCalendar)

    func day(_ offset: Int, hour: Int = 10) -> Date {
        let start = testCalendar.startOfDay(for: referenceDate)
        return testCalendar.date(byAdding: .day, value: offset, to: start)!.addingTimeInterval(Double(hour) * 3600)
    }

    func testConsecutiveDaysEndingToday() {
        let sessions = [-2, -1, 0].map { completedSession(endingAt: day($0)) }
        let days = streaks.focusDays(from: sessions)
        XCTAssertEqual(streaks.currentStreak(days: days, today: day(0, hour: 20)), 3)
        XCTAssertEqual(streaks.longestStreak(days: days), 3)
    }

    func testMultipleSessionsOnOneDayCountOnce() {
        let sessions = [completedSession(endingAt: day(0, hour: 9)),
                        completedSession(endingAt: day(0, hour: 11)),
                        completedSession(endingAt: day(0, hour: 22))]
        let days = streaks.focusDays(from: sessions)
        XCTAssertEqual(days.count, 1)
        XCTAssertEqual(streaks.currentStreak(days: days, today: day(0, hour: 23)), 1)
    }

    func testStreakStillStandsBeforeFocusingToday() {
        let sessions = [-3, -2, -1].map { completedSession(endingAt: day($0)) }
        let days = streaks.focusDays(from: sessions)
        XCTAssertEqual(streaks.currentStreak(days: days, today: day(0, hour: 8)), 3)
    }

    func testGapResetsCurrentStreakButKeepsLongest() {
        let sessions = [-6, -5, -4, -3, -1, 0].map { completedSession(endingAt: day($0)) }
        let days = streaks.focusDays(from: sessions)
        XCTAssertEqual(streaks.currentStreak(days: days, today: day(0)), 2)
        XCTAssertEqual(streaks.longestStreak(days: days), 4)
    }

    func testMissingAWholeDayResetsToZero() {
        let sessions = [-3, -2].map { completedSession(endingAt: day($0)) }
        let days = streaks.focusDays(from: sessions)
        XCTAssertEqual(streaks.currentStreak(days: days, today: day(0)), 0)
        XCTAssertEqual(StatsCalculator.streakLine(current: 0), "A streak starts with any one session.")
    }

    func testAbandonedSessionsDoNotCreateFocusDays() {
        let engine = FocusTimerEngine()
        let abandoned = engine.abandon(makeSession(.countdown(25), at: day(0)), at: day(0).addingTimeInterval(600))
        XCTAssertTrue(streaks.focusDays(from: [abandoned]).isEmpty)
    }

    func testSessionIsAttributedToTheDayItEnded() {
        // Starts 23:50 on day -1, ends 00:15 on day 0.
        let end = testCalendar.startOfDay(for: referenceDate).addingTimeInterval(15 * 60)
        let session = completedSession(endingAt: end, focusMinutes: 25)
        XCTAssertEqual(streaks.focusDays(from: [session]), [testCalendar.startOfDay(for: referenceDate)])
    }
}

final class StatsCalculatorTests: XCTestCase {
    func testStatsDeriveFromPersistedData() {
        let calculator = StatsCalculator(calendar: testCalendar)
        let today = referenceDate
        let yesterday = testCalendar.date(byAdding: .day, value: -1, to: today)!
        let tenDaysAgo = testCalendar.date(byAdding: .day, value: -10, to: today)!
        let sessions = [
            completedSession(endingAt: today, focusMinutes: 25),
            completedSession(endingAt: today.addingTimeInterval(-7200), focusMinutes: 50),
            completedSession(endingAt: yesterday, focusMinutes: 30),
            completedSession(endingAt: tenDaysAgo, focusMinutes: 20),
            FocusTimerEngine().abandon(makeSession(.countdown(25), at: today), at: today.addingTimeInterval(300))
        ]
        let usages = [
            ActivityUsage(id: UUID(), activityID: .sudoku, startedAt: today, endedAt: today, outcome: .completed, context: .shelf),
            ActivityUsage(id: UUID(), activityID: .sudoku, startedAt: today, endedAt: today, outcome: .abandoned, context: .shelf),
            ActivityUsage(id: UUID(), activityID: .doNothing, startedAt: today, endedAt: today, outcome: .completed, context: .shelf)
        ]
        let stats = calculator.stats(sessions: sessions, usages: usages, now: today.addingTimeInterval(3600))

        XCTAssertEqual(stats.completedSessions, 4)
        XCTAssertEqual(stats.totalFocus, minutes(125))
        XCTAssertEqual(stats.todayFocus, minutes(75))
        XCTAssertEqual(stats.weekFocus, minutes(105))
        XCTAssertEqual(stats.averageSessionDuration, minutes(125) / 4)
        XCTAssertEqual(stats.currentStreak, 2)
        XCTAssertEqual(stats.lastSevenDays.count, 7)
        XCTAssertEqual(stats.lastSevenDays.last?.sessionCount, 2)
        XCTAssertEqual(stats.activitiesCompleted, 2)
        XCTAssertEqual(stats.activityUsage.first?.activityID, .sudoku)
        XCTAssertEqual(stats.activityUsage.first?.openedCount, 2)
    }

    func testEmptyHistory() {
        let stats = StatsCalculator(calendar: testCalendar).stats(sessions: [], usages: [], now: referenceDate)
        XCTAssertFalse(stats.hasHistory)
        XCTAssertEqual(stats.averageSessionDuration, 0)
        XCTAssertEqual(stats.lastSevenDays.map(\.focusDuration), Array(repeating: 0, count: 7))
    }
}

final class ProgressionTests: XCTestCase {
    let evaluator = ProgressionEvaluator()
    let catalog = SceneCatalog.all

    func testMilestonesMatchSpecification() {
        XCTAssertEqual(SceneCatalog.rainyBedroom.unlockRule, .initiallyUnlocked)
        XCTAssertEqual(SceneCatalog.libraryLight.unlockRule, .completedSessions(7))
        XCTAssertEqual(SceneCatalog.trainWindow.unlockRule, .completedSessions(15))
        XCTAssertEqual(SceneCatalog.nightCity.unlockRule, .completedSessions(25))
    }

    func testUnlocksAtExactThresholds() {
        XCTAssertEqual(evaluator.unlockedScenes(in: catalog, completedSessions: 0).map(\.id), [.rainyBedroom])
        XCTAssertEqual(evaluator.unlockedScenes(in: catalog, completedSessions: 6).map(\.id), [.rainyBedroom])
        XCTAssertEqual(evaluator.unlockedScenes(in: catalog, completedSessions: 7).map(\.id), [.rainyBedroom, .libraryLight])
        XCTAssertEqual(evaluator.unlockedScenes(in: catalog, completedSessions: 15).count, 3)
        XCTAssertEqual(evaluator.unlockedScenes(in: catalog, completedSessions: 25).count, 4)
    }

    func testNextLockedSceneAndRemaining() {
        let next = evaluator.nextLockedScene(in: catalog, completedSessions: 4)
        XCTAssertEqual(next?.scene.id, .libraryLight)
        XCTAssertEqual(next?.remaining, 3)
        XCTAssertNil(evaluator.nextLockedScene(in: catalog, completedSessions: 30))
    }

    func testNewlyUnlockedBetweenCounts() {
        XCTAssertEqual(evaluator.newlyUnlocked(in: catalog, before: 6, after: 7).map(\.id), [.libraryLight])
        XCTAssertTrue(evaluator.newlyUnlocked(in: catalog, before: 7, after: 8).isEmpty)
        XCTAssertEqual(evaluator.newlyUnlocked(in: catalog, before: 0, after: 30).count, 3)
    }

    func testAbandonedSessionsDoNotUnlock() {
        let clock = ManualClock(referenceDate)
        let container = makeContainer(clock: clock)
        for _ in 0..<10 {
            container.focus.start(presetID: .defaultPreset, taskID: nil, source: .manual)
            clock.advance(by: minutes(10))
            container.focus.endEarly()
        }
        XCTAssertEqual(container.focus.completedSessionCount, 0)
        XCTAssertEqual(evaluator.unlockedScenes(in: catalog, completedSessions: container.focus.completedSessionCount).count, 1)
    }

    func testPlantStageIsFullUntilGrowthShips() {
        XCTAssertEqual(evaluator.plantStage(completedSessions: 0, growthEnabled: false), .full)
        XCTAssertEqual(evaluator.plantStage(completedSessions: 0, growthEnabled: true), .sprout)
        XCTAssertEqual(evaluator.plantStage(completedSessions: 12, growthEnabled: true), .full)
    }
}
