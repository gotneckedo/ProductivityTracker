import XCTest
#if canImport(StillCore)
@testable import StillCore
#else
@testable import Still
#endif

/// A fixed Gregorian calendar in UTC so day boundaries are deterministic.
let testCalendar: Calendar = {
    var calendar = Calendar(identifier: .gregorian)
    calendar.timeZone = TimeZone(identifier: "UTC")!
    return calendar
}()

/// 2026-03-10 09:00:00 UTC.
let referenceDate: Date = {
    var components = DateComponents()
    components.year = 2026
    components.month = 3
    components.day = 10
    components.hour = 9
    return testCalendar.date(from: components)!
}()

func makeContainer(
    clock: ManualClock = ManualClock(referenceDate),
    notifications: RecordingNotificationScheduler = RecordingNotificationScheduler(authorization: .granted)
) -> DependencyContainer {
    DependencyContainer.inMemory(clock: clock, calendar: testCalendar, notifications: notifications)
}

func minutes(_ value: Double) -> TimeInterval { value * 60 }

extension TimerConfiguration {
    static func countdown(_ focusMinutes: Double) -> TimerConfiguration {
        var configuration = TimerConfiguration.standard
        configuration.mode = .countdown
        configuration.focusDuration = minutes(focusMinutes)
        return configuration
    }

    static func pomodoro(focus: Double, rest: Double, cycles: Int, autoBreaks: Bool = true, autoFocus: Bool = true) -> TimerConfiguration {
        TimerConfiguration(
            mode: .pomodoro,
            focusDuration: minutes(focus),
            breakDuration: minutes(rest),
            longBreakDuration: minutes(15),
            longBreakInterval: 0,
            cycleCount: cycles,
            autoStartBreaks: autoBreaks,
            autoStartFocus: autoFocus,
            routineID: nil
        )
    }

    static var countUp: TimerConfiguration {
        var configuration = TimerConfiguration.standard
        configuration.mode = .countUp
        return configuration
    }
}

func makeSession(_ configuration: TimerConfiguration, at date: Date = referenceDate, taskID: UUID? = nil) -> FocusSession {
    FocusTimerEngine().makeSession(
        id: UUID(),
        configuration: configuration,
        taskID: taskID,
        sceneID: .rainyBedroom,
        renderMode: .scene,
        presetID: .defaultPreset,
        source: .manual,
        at: date
    )
}

/// A completed session that ended at `end`.
func completedSession(endingAt end: Date, focusMinutes: Double = 25) -> FocusSession {
    let engine = FocusTimerEngine()
    let start = end.addingTimeInterval(-minutes(focusMinutes))
    let session = makeSession(.countdown(focusMinutes), at: start)
    return engine.advance(session, to: end).0
}
